
# Asymptotic covariance of ML variance estimates
cov.var.re=function(shat,dhat,n.vec){
  N=sum(n.vec)
  V11=N*shat^(-4)
  V12=shat^(-2)*sum(n.vec/(1+n.vec*dhat))
  V22=sum((n.vec/(1+n.vec*dhat))^2)
  return(2*solve(matrix(c(V11,V12,V12,V22),nrow=2)))
  
}

# ============================================
#  This cleans up tbi data 
# =============================================

nacol=function(x){
  sum(is.na(x))
}

is.match = function(x,vec){

  match = rep ( FALSE, length(x) )
  for ( i in 1:length(x)) {
  for ( j in 1:length(vec)){
    if ( x[i] == vec[j] ) {
    match[i] = TRUE }
  }

   }
  match
}

clean.data = function(tbi.data,col.index,visitn=4,groups= NULL,col.omit=NULL){
    # Use this to omit sporadic missingness
    # col.index = which columns to include
  col.index.full = col.index
  if( !is.null(col.omit)){ col.index = col.index[-col.omit] }
  if ( is.null(groups)){
  	visit.ind = which(tbi.data$visit ==visitn)}
  if ( !is.null(groups) ){
	visit.ind = which( tbi.data$visit == visitn & (is.match(tbi.data$group, groups ) ) )
  }
  not.nas = apply(tbi.data[visit.ind,col.index],1,nacol) 
  tbi.data2 = tbi.data[visit.ind,][not.nas==0 ,col.index.full]
  fact = as.factor(tbi.data[,3]*tbi.data[,11])[visit.ind][not.nas==0]
  
  return(list(tbi=tbi.data2,factor = fact))
}

dirty.data = function(tbi.data,col.index,visitn=4,groups= NULL,col.omit=NULL){
  
  col.index.full = col.index
  if( !is.null(col.omit)){ col.index = col.index[-col.omit] }
  if ( is.null(groups)){
  	visit.ind = which(tbi.data$visit ==visitn)}
  if ( !is.null(groups) ){
	visit.ind = which( tbi.data$visit == visitn & (is.match(tbi.data$group, groups ) ) )
  }
  tbi.data2 = tbi.data[visit.ind,][ ,col.index.full]
  fact = as.factor(tbi.data[,3]*tbi.data[,11])[visit.ind]  
  return(list(tbi=tbi.data2,factor = fact))
}


# =======================================
#  Function to estimate parameters in analysis
#  model and pool estimates
# =======================================

analyze_TBI_imp =function(Y.array,Y_col,x_fact, x_cols,impname=NULL){
  # Y_col = response variable
  # x_cols = columns to use as fixed covariates
  # Y.array : n by p by n_imp array.  Each [,,k] is full completed dataset.
  
  X=model.matrix( ~ 0 + x_fact)
  nvec=diag(t(X)%*%X)
  p = length(x_cols)
  
  model.list = list()
  nimpp=dim(Y.array)[3]
  mi.comb = matrix(NA,nrow=3+p,ncol=4)
  mi.beta = array(NA,dim=c(nimpp,1+p,2))
  mi.sigma = matrix(NA,nrow=nimpp,ncol=2)
  mi.psi = matrix(NA,nrow=nimpp,ncol=2)

  
  for(k in 1:nimpp){
      XTEMP = (Y.array[,x_cols,k]) 
      Y = Y.array[,Y_col,k]
      lm3=lmer( Y ~XTEMP+(1|x_fact))
      vHat3=cov.var.re(sqrt(attr(VarCorr(lm3),"sc")^2),sqrt(as.numeric(VarCorr(lm3))),nvec)
      mi.beta[k,,]=cbind(fixef(lm3),sqrt(diag(vcov(lm3))))
      mi.sigma[k,] =c( attr(VarCorr(lm3),"sc")^2, sqrt(vHat3[1,1]))
      mi.psi[k,] = c(as.numeric(VarCorr(lm3)),sqrt(vHat3[2,2]) )
      model.list[[k]] = lm3
  }
  ######################
  # combine rows to get MI ests
  betatemp = cbind(apply(mi.beta,2:3,mean),apply(mi.beta[,,1],2,sd))   # rearrange in final table
  mi.comb[1:(1+p),1:3] = betatemp[c(1,7,8,2:6),]
  mi.comb[(2+p),1:3] = c(apply(mi.sigma,2,mean),sd(mi.sigma[,1]))
  mi.comb[(3+p),1:3] = c(apply(mi.psi,2,mean),sd(mi.psi[,1]))
  
  # fourth col for between-imp
  mi.comb[,4] = sqrt( mi.comb[,2]^2+mi.comb[,3]^2*(1+1/nimpp) )
  
  return(mi.comb)
}

# For zses omitted from analysis model
analyze_TBI_imp_2 =function(Y.array,Y_col,x_fact, x_cols,impname=NULL){
  # Y_col = response variable
  # x_cols = columns to use as fixed covariates
  # Y.array : n by p by n_imp array.  Each [,,k] is full completed dataset.
  model.list = list()
  X=model.matrix( ~ 0 + x_fact)
  nvec=diag(t(X)%*%X)
  p = length(x_cols)
 
  nimpp=dim(Y.array)[3]
  mi.comb = matrix(NA,nrow=3+p,ncol=4)
  mi.beta = array(NA,dim=c(nimpp,1+p,2))
  mi.sigma = matrix(NA,nrow=nimpp,ncol=2)
  mi.psi = matrix(NA,nrow=nimpp,ncol=2)

  
  for(k in 1:nimpp){
      XTEMP = (Y.array[,x_cols,k]) 
      Y = Y.array[,Y_col,k]
      lm3=lmer( Y ~XTEMP+(1|x_fact))
      vHat3=cov.var.re(sqrt(attr(VarCorr(lm3),"sc")^2),sqrt(as.numeric(VarCorr(lm3))),nvec)
      mi.beta[k,,]=cbind(fixef(lm3),sqrt(diag(vcov(lm3))))
      mi.sigma[k,] =c( attr(VarCorr(lm3),"sc")^2, sqrt(vHat3[1,1]))
      mi.psi[k,] = c(as.numeric(VarCorr(lm3)),sqrt(vHat3[2,2]) )
      model.list[[k]] = lm3
  }
  ######################
  # combine rows to get MI ests
  betatemp = cbind(apply(mi.beta,2:3,mean),apply(mi.beta[,,1],2,sd))   # rearrange in final table
  mi.comb[1:(1+p),1:3] = betatemp[c(1,7,2:6),]
  mi.comb[(2+p),1:3] = c(apply(mi.sigma,2,mean),sd(mi.sigma[,1]))
  mi.comb[(3+p),1:3] = c(apply(mi.psi,2,mean),sd(mi.psi[,1]))
  
  # fourth col for between-imp
  mi.comb[,4] = sqrt( mi.comb[,2]^2+mi.comb[,3]^2*(1+1/nimpp) )
  
  #return(mi.comb)
  return(list(mi.comb,model.list))
}


# imputation function when response in substantive model is not imputed

beta2.XimputedBig=function(imp.array,Yvar,x,XM=NULL,impname=NULL){
  #the response variable is now Yvar!
  #both vars in imp.array will be covariates
  
  X=model.matrix( ~ 0 + x)
  nvec=diag(t(X)%*%X)
 
  nimpp=dim(imp.array)[1]
  mi.comb = matrix(NA,nrow=5+dim(XM)[2],ncol=4)
  mi.beta = array(NA,dim=c(nimpp,3+dim(XM)[2],2))
  mi.sigma = matrix(NA,nrow=nimpp,ncol=2)
  mi.psi = matrix(NA,nrow=nimpp,ncol=2)
  
  for(k in 1:nimpp){
      if ( !is.null(XM)) { XTEMP = cbind(imp.array[k,,],XM) }
      if (is.null(XM))  { XTEMP = imp.array[k,,] }
      lm3=lmer( Yvar ~XTEMP+(1|x))
      vHat3=cov.var.re(sqrt(attr(VarCorr(lm3),"sc")^2),sqrt(as.numeric(VarCorr(lm3))),nvec)
      mi.beta[k,,]=cbind(fixef(lm3),sqrt(diag(vcov(lm3))))
      mi.sigma[k,] =c( attr(VarCorr(lm3),"sc")^2, sqrt(vHat3[1,1]))
      mi.psi[k,] = c(as.numeric(VarCorr(lm3)),sqrt(vHat3[2,2]) )
  }
  ######################
  # combine rows to get MI ests
  
  mi.comb[1:(3+dim(XM)[2]),1:3] =c(apply(mi.beta,2:3,mean),apply(mi.beta[,,1],2,sd))
  mi.comb[(4+dim(XM)[2]),1:3] = c(apply(mi.sigma,2,mean),sd(mi.sigma[,1]))
  mi.comb[(5+dim(XM)[2]),1:3] = c(apply(mi.psi,2,mean),sd(mi.psi[,1]))
  
  # fourth col for between-imp
  mi.comb[,4] = sqrt( mi.comb[,2]^2+mi.comb[,3]^2*(1+1/nimpp) )
  
  return(mi.comb)
}


 MICE_ML2= function( x.fact, Ymat, X.dat,  nimp = 60, n.it = 50)
{
  eps_sig = .0000005
  eps_psi = .0000001
  Yimp = array(NA, dim=c(nimp, nrow(Ymat), ncol(Ymat) ) )
  Ypreds = Yimp
  pmiss = ncol(Ymat)
  N = nrow(Ymat)
  m = length(unique(x.fact))
  Xm = model.matrix(~0+as.factor(x.fact))
  nvec = diag( t(Xm)%*%Xm )
  miss_inds = list()

  # initialize missing values in Ymat
  for( p in 1:pmiss)
  {
  miss_inds[[p]] = which(is.na(Ymat[,p]))
  Ymat[which(is.na(Ymat[,p])),p] = rnorm( length(which(is.na(Ymat[,p]))), c(1,0,0,0)[p],1 )

  }

  for( h in 1:nimp)
  {

 	for( p in 1:pmiss)
  	{
  	#Ymat[miss_inds[[p]],p] = rnorm( length(miss_inds[[p]]), c(3,50,50,50)[p],1 )
  	Ymat[miss_inds[[p]],p] = rnorm( length(miss_inds[[p]]), c(3,0,0,0)[p],1 )

  	}

  for( k in 1:n.it)
  {
      
  for( p in 1:pmiss)
	{
      rm(fitw.R)
	    m_ind = miss_inds[[p]]
  	  x_mind=factor(as.numeric(x.fact[-m_ind]))
      Jn_r =(model.matrix(~0+x_mind))%*%t(model.matrix(~0+x_mind))
      X2_temp = cbind( Ymat[-m_ind,c(1,2)[-p]], add_ybar(Ymat[-m_ind,-c(1,2,p)], x.fact[-m_ind]) )
      X2_temp2 = cbind( Ymat[m_ind,c(1,2)[-p]], add_ybar(Ymat[m_ind,-c(1,2,p)], x.fact[m_ind]) )

	    X2_r = as.matrix( cbind(X2_temp, X.dat[-m_ind,]) )
	    X2_r_int = as.matrix( cbind(rep(1, nrow(X2_temp)),X2_r ))
	    X2_r2 = as.matrix( cbind(rep(1,length(m_ind)),X2_temp2, X.dat[m_ind,]) )
      X2_r = as.matrix( cbind(X2_temp, X.dat[-m_ind,]) )
	
      if( p != 3) 
      {
      fitw.R=lmer(Ymat[-m_ind,p] ~X2_r +(1|x_mind),REML=TRUE,InstEval,
      control = lmerControl(calc.derivs = FALSE))
      }

     if( p == 3)
     {

     fitw.R.list = tryCatch({
     list( TRUE, lmer(Ymat[-m_ind,p] ~X2_r +(1|x_mind),REML=TRUE,InstEval, control = lmerControl(calc.derivs = FALSE)) ) 
      },  error = function(e) {
     X2_r = X2_r[,-4] 
     X2_r_int = as.matrix( cbind(rep(1, nrow(X2_temp)),X2_r ))
     X2_r2 = as.matrix( cbind(rep(1,length(m_ind)),X2_temp2[,-4], X.dat[m_ind,]) )
     fitw.R=lmer(Ymat[-m_ind,p] ~X2_r +(1|x_mind),REML=TRUE,InstEval, control = lmerControl(calc.derivs = FALSE))
     return(list(FALSE, fitw.R, X2_r, X2_r_int, X2_r2)) } ) 
     
     if( fitw.R.list[[1]]==TRUE) { fitw.R = fitw.R.list[[2]] }
     if( fitw.R.list[[1]]==FALSE) { fitw.R = fitw.R.list[[2]];#
						X2_r = fitw.R.list[[3]];
						X2_r_int = fitw.R.list[[4]];
						X2_r2 = fitw.R.list[[5]]; }
      } # end p=3 loop


	s.hat.R=attr(VarCorr(fitw.R),"sc")^2
	p.hat.R=as.numeric(VarCorr(fitw.R)$x)

	varhat.R=s.hat.R*diag(length(Ymat[-m_ind,p]))+p.hat.R*Jn_r
	beta.hat.R=fixef(fitw.R)
	var.betahat.R=solve( t(X2_r_int)%*%solve(varhat.R)%*%X2_r_int )
	beta.tilde.R=mvrnorm(1,beta.hat.R,var.betahat.R)
	var.sphat.R=cov.var.re(sqrt(s.hat.R),sqrt(p.hat.R),n.vec=nvec)
	pd=sum(eigen(var.sphat.R)$values<0)==0
 
	if(!pd)
    	{
      	var.newR=c(s.hat.R,p.hat.R) # following Resche-Rigon, use improper imp if not PD
    	} else{
      	success=0
      	while(success==0)
      {
        	var.newR=mvrnorm(1,c(s.hat.R,p.hat.R),var.sphat.R)
        	if(var.newR[1]>0 & var.newR[2]>0){success=1}       }
    	}

    	eps.imp=rnorm(length(m_ind),0,sqrt(var.newR[1]))

	# Impute missing values
 
	# case 1: sporadic missing
      if(  p==1 | p ==2 )
      {
      qind = as.numeric( x.fact[m_ind] ); qind[qind==6] = 5
      t.imp = ranef(fitw.R)$x_mind[as.numeric( x.fact[m_ind]),1]
  	yr.imp=X2_r2%*%beta.tilde.R+eps.imp+t.imp
	 }
      
      # this section is specific to TBI example 2
      if( p == 3)
      {
    	t.imp=rep(0,m)
      m.miss = length(unique(x.fact[-m_ind]))
    	t.imp[1:3]=rnorm(m-m.miss,0,sqrt(var.newR[2]))
     	yr.imp=X2_r2%*%beta.tilde.R+eps.imp+Xm[m_ind,]%*%t.imp
	    }

      if( p == 4 )
      {
	    # systematic missingness in ps4, no sporadic
    	t.imp=rep(0,m)
      m.miss = length(unique(x.fact[-m_ind]))
    	t.imp[4]=rnorm(m-m.miss,0,sqrt(var.newR[2]))
	    yr.imp=X2_r2%*%beta.tilde.R+eps.imp+Xm[m_ind,]%*%t.imp
	   }

      Ymat[m_ind,p]=yr.imp
      Ypreds[h,m_ind,p] = yr.imp
    	
	}   # end of p loop
 }   # end of k loop

    Yimp[h,,] = as.matrix(Ymat)

 }
  Yimp
}


MICE_ML2_tbi1 = function( x.fact, Ymat, X.dat,  nimp = 60, n.it = 50 )
{

  Yimp = array(NA, dim=c(nimp, nrow(Ymat), ncol(Ymat) ) )
  Ypreds = Yimp
  pmiss = ncol(Ymat)
  N = nrow(Ymat)

  m = length(unique(x.fact))
  Xm = model.matrix(~0+as.factor(x.fact))
  nvec = diag( t(Xm)%*%Xm )
  miss_inds = list()

  # initialize missing values in Ymat
  for( p in 1:pmiss)
  {
  miss_inds[[p]] = which(is.na(Ymat[,p]))
  Ymat[which(is.na(Ymat[,p])),p] = rnorm( length(which(is.na(Ymat[,p]))), c(1,50,50,50)[p],1 )
  }

  for( h in 1:nimp)
  {

        for( p in 1:pmiss)
        {
        Ymat[miss_inds[[p]],p] = rnorm( length(miss_inds[[p]]), c(3,50,50,50)[p],1 )
        }

  for( k in 1:n.it)
  {

  for( p in 1:pmiss)
  {

  m_ind = miss_inds[[p]]
  x_mind=factor(as.numeric(x.fact[-m_ind]))
  Jn_r =(model.matrix(~0+x_mind))%*%t(model.matrix(~0+x_mind))
  
  X2_temp = cbind( Ymat[-m_ind,c(1,2)[-p]], add_ybar(Ymat[-m_ind,-c(1,2,p)], x.fact[-m_ind]) )
  X2_temp2 = cbind( Ymat[m_ind,c(1,2)[-p]], add_ybar(Ymat[m_ind,-c(1,2,p)], x.fact[m_ind]) )
  X2_r = as.matrix( cbind(X2_temp, X.dat[-m_ind,]) )
  X2_r_int = as.matrix( cbind(rep(1, nrow(X2_temp)),X2_r ))
  X2_r2 = as.matrix( cbind(rep(1,length(m_ind)),X2_temp2, X.dat[m_ind,]) )

  fitw.R=lmer(Ymat[-m_ind,p] ~X2_r +(1|x_mind),REML=T,InstEval,  control = lmerControl(calc.derivs = FALSE))
  
  s.hat.R=attr(VarCorr(fitw.R),"sc")^2
  p.hat.R=as.numeric(VarCorr(fitw.R)$x)


  varhat.R=s.hat.R*diag(length(Ymat[-m_ind,p]))+p.hat.R*Jn_r
  beta.hat.R=fixef(fitw.R)
  var.betahat.R=solve( t(X2_r_int)%*%solve(varhat.R)%*%X2_r_int )
  beta.tilde.R=mvrnorm(1,beta.hat.R,var.betahat.R)
  var.sphat.R=cov.var.re(sqrt(s.hat.R),sqrt(p.hat.R),n.vec=nvec)
  
  pd=sum(eigen(var.sphat.R)$values<0)==0
  if(!pd)
  {
   var.newR=c(s.hat.R,p.hat.R) # following RR, use improper imp if not PD
  }
  else
  {
   success=0
   while(success==0)
   {
    # draw variances parameters from truncated normal
    var.newR=mvrnorm(1,c(s.hat.R,p.hat.R),var.sphat.R)
    if(var.newR[1]>0 & var.newR[2]>0){success=1}       
   }
   }

   eps.imp=rnorm(length(m_ind),0,sqrt(var.newR[1]))

   
   # Impute missing values
   # case 1: for sporadic missing
      if(  p==1 | p ==2 )
      {
      qind = as.numeric( x.fact[m_ind] ); qind[qind==6] = 5
      t.imp = ranef(fitw.R)$x_mind[as.numeric( x.fact[m_ind]),1]
      yr.imp=X2_r2%*%beta.tilde.R+eps.imp+t.imp
      }

      #this section is for TBI example 1
      if( p == 3)
      {
        t.imp=rep(0,m)
        m.miss = length(unique(x.fact[-m_ind]))
        t.imp[2]=rnorm(m-m.miss,0,sqrt(var.newR[2]))
        yr.imp=X2_r2%*%beta.tilde.R+eps.imp+Xm[m_ind,]%*%t.imp
      }

      if( p == 4 )
      {
         #systematic missingness in ps5, sporadic in 2
        t.imp=rep(0,m)
        t.imp[2] = ranef(fitw.R)$x_mind[2,1]
        m.miss = length(unique(x.fact[-m_ind]))
        t.imp[5]=rnorm(m-m.miss,0,sqrt(var.newR[2]))
        yr.imp=X2_r2%*%beta.tilde.R+eps.imp+Xm[m_ind,]%*%t.imp
      }

      Ymat[m_ind,p]=yr.imp
      Ypreds[h,m_ind,p] = yr.imp
        
        }   # end of p loop
     }   # end of k loop
    Yimp[h,,] = as.matrix(Ymat)
 }
  Yimp
}

 