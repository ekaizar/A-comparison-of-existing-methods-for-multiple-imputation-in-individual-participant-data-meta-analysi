
# ===================================
# Simulation 5
# unbalanced design, 5 studies
# Different priors used
# ===================================

rm(list=ls())
#install.packages("mice_5.1.tar.gz", repos = NULL, type = "source")  # Uncomment for IW(5,1) prior
#install.packages("mice_5.2.tar.gz", repos = NULL, type = "source")  # Uncomment for IW(1.6,1) prior
#install.packages("mice")
library("mice")
library("pan")
library("MASS")
library("lme4")
library("foreach")
library("doParallel")

cl <- makeCluster(8)
registerDoParallel(cl)

# run this first
source("MIfunctions_2016_06.R")

# Setup
Sig = matrix( c( 127, 100,75, 100,169, 65, 75,65,120), nrow=3)
psi = matrix(c(28,22,11, 22,40, 12, 11, 12, 26), nrow=3)

ndat = 200
nimp = 60
nmat = 9
nit = 100
m=5
nvec = c( 49, 18, 15, 29, 60) 
nindices=cbind(c(1,cumsum(nvec[-length(nvec)])+1),c(cumsum(nvec)))
N=sum(nvec)
x=NULL
for(k in 1:length(nvec)){  x=c(x,rep(k,nvec[k])) }
D=data.frame(o=rep(1,N),x=as.factor(x))
X=model.matrix(~0+as.factor(x))
jn=X%*%t(X)

betamean=array(NA,dim=c(nmat,25,4))
r = 4
p =3
E=Sig
P = psi
n1 = nvec[1]  
betaest=array(NA,dim=c(ndat,25,4))
  
params_thisr <- foreach( l = 1:ndat)%dopar%{

   library("mice")
   library("pan")
   library("MASS")
   library("lme4")
  
   set.seed(20170303+l)  # Set seed to use the same data for each prior
    
    # Generate data and missingness
    eps=mvrnorm(N,rep(0,p),Sig=E) 
    t=mvrnorm(m,rep(0,p),Sig=psi)
    y1=eps[,1]+X%*%(t[,1])
    y2=eps[,2]+X%*%(t[,2])
    y3= eps[,3]+X%*%(t[,3])
    y1bar=X%*%t(X)%*%y1
    y2bar=X%*%t(X)%*%y2
    y3bar=X%*%t(X)%*%y3
    y.full=cbind(y1,y2)
    y1=y.full[,1]
    y2=y.full[,2]
    mind.2=which(x==5)
    mind.1=which(x==2)
    m.v1=length(unique(x[-mind.1])); m.v2=length(unique(x[-mind.2]))
    xm1=factor(as.numeric(x[-mind.1]))
    xm2=as.factor(as.numeric(x[-mind.2]))
    x=as.factor(x)
    jn21=(model.matrix(~0+xm1))%*%t(model.matrix(~0+xm1))
    jn22=(model.matrix(~0+xm2))%*%t(model.matrix(~0+xm2))
    

    y1[mind.1]=NA
    y2[mind.2]=NA
    y1bar[mind.1]=NA
    y2bar[mind.2]=NA
    y.tot=cbind(y1,y1bar,y2,y2bar,as.numeric(x),rep(1,length(y1)))
    y.tot2 = cbind(y1,y2,as.numeric(x),rep(1,length(y1)))
    y1f=y1
    y2f=y2
    y2fbar=y2bar
    y1fbar=y1bar
    
    impf1=matrix(NA,nrow=nimp,ncol=length(mind.1))
    impf2=matrix(NA,nrow=nimp,ncol=length(mind.2))
    impfREML1=matrix(NA,nrow=nimp,ncol=length(mind.1))
    impfREML2=matrix(NA,nrow=nimp,ncol=length(mind.2))
    
    # MICE - ML
    mice.compREML = mice.RR(y1f,y2f,X.dat = as.matrix(y3),x.fact=x,n.imp=nimp, n.it = nit)
    mice.compREML = mice.compREML[[1]]
  
    init=mice(cbind(y3,y.tot2),nit=0)
    pred1=init$pred
    pred1[2,]=c(1,0,3,-2,1)
    pred1[3,]=c(1,3,0,-2,1)
    pred2 = init$pred
    pred2[2,]=c(1,0,1,-2,1)
    pred2[3,]=c(1,1,0,-2,1)
    
    # MICE -IW compatible
    impm1=mice(cbind(y3,y.tot2),predictorMatrix=pred1,m=nimp,method=c("","2l.pan","2l.pan","",""),maxit=nit, print=FALSE)   
  
    # MICE - IW  
    impm2=mice(cbind(y3,y.tot2),predictorMatrix=pred2,m=nimp,method=c("","2l.pan","2l.pan","",""),maxit=nit,print=FALSE)
  
    y1.mice=impm1$imp$y1
    y2.mice=impm1$imp$y2
    pan.comp1=array(NA,dim=c(nimp,dim(y.full)))
    pan.comp2=pan.comp1
    pan.comp3=pan.comp2
    for(j in 1:nimp)
      {
      pan.comp1[j,,]=y.full
      pan.comp1[j,mind.1,1]=y1.mice[,j]
      pan.comp1[j,mind.2,2]=y2.mice[,j] 
      }
    
    y1.mice2=impm2$imp$y1
    y2.mice2=impm2$imp$y2
    for(j in 1:nimp)
      {
      pan.comp2[j,,]=y.full
      pan.comp2[j,mind.1,1]=y1.mice2[,j]
      pan.comp2[j,mind.2,2]=y2.mice2[,j] 
      }
    
    # Joint model
    pri=list(a=2,Binv=diag(rep(1,2)),c=2,Dinv=diag(rep(1,2)))
    for( j in 1:nimp)
    {
      imp3=pan(y.tot[,c(1,3)],x,cbind(y3,y.tot[,c(6)]),xcol=1:2,zcol=2,prior=pri,seed=round(runif(1, 1, 10^7)),
               iter=1000)
      pan.comp3[j,,]=imp3$y  
    }
    
    TEMP = matrix(NA,nrow=5*5,ncol=4)
    TEMP[c(1,6,11,16,21),]=beta2.fulldata.Ximputed(cbind(y3,y.full),r.col=1,x=x,XM=NULL)
    TEMP[c(2,7,12,17,22),]=beta2.Ximputed(pan.comp1,Yvar=as.matrix(y3),x,XM=NULL)
    TEMP[c(3,8,13,18,23),]=beta2.Ximputed(pan.comp2,Yvar=y3,x,XM=NULL)
    TEMP[c(4,9,14,19,24),]=beta2.Ximputed(pan.comp3,Yvar=y3,x,XM=NULL)
    TEMP[c(5,10,15,20,25),]=beta2.Ximputed(mice.compREML,Yvar=as.matrix(y3),x,XM=NULL)

    betaest[l,,]=TEMP
    betaest
  }
  
