# =================================
# Simulation4:
# Random slopes with 3rd variable in 
# imputation and substantive model
# ==================================

# setup
rm(list=ls())
library("mice")
library("pan")
library("MASS")
library("lme4")
library("foreach")
library("doParallel")

cl <- makeCluster(8)
registerDoParallel(cl)
source("MIfunctions_2016_06.R")

# Covariance matrices
sig.cand1 = matrix(c(10,1.5,6.0,1.5,10,4.0,6,4,15),nrow=3)
sig.cand2 = matrix(c(10,7.5,6,7.5,10,4,6,4,15),nrow=3)
sig.cand3 = (sqrt(c(10,1,10)))%*%t( sqrt(c(10,1,10)))*matrix(c(1,-.55,.6,-.55,1,-.4,.6,-.4,1),nrow=3)
sig.cand4 =matrix(c(10,-5.5,6,-5.5,10,-4,6,-4,15),nrow=3)
sig.cand5 = (sqrt(c(10,1,10)))%*%t( sqrt(c(10,1,10)))*matrix(c(1,.75,.6,.75,1,.4,.6,.4,1),nrow=3)
sig.cand6 =matrix(c(10,-5.5,6,-5.5,10,4,6,4,15),nrow=3)

sig.array=array(NA,dim=c(12,3,3))
psi.array=array(NA,dim=c(12,3,3))

sig.array[1,,]=sig.cand1; psi.array[1,,]=sig.cand1/10
sig.array[2,,]=sig.cand2; psi.array[2,,]=sig.cand1/10
sig.array[3,,]=sig.cand6; psi.array[3,,]=sig.cand1/10
sig.array[4,,]=sig.cand1; psi.array[4,,]=sig.cand2/10
sig.array[5,,]=sig.cand2; psi.array[5,,]=sig.cand2/10
sig.array[6,,]=sig.cand6; psi.array[6,,]=sig.cand2/10
sig.array[7,,]=sig.cand1; psi.array[7,,]=sig.cand6/10
sig.array[8,,]=sig.cand2; psi.array[8,,]=sig.cand6/10
sig.array[9,,]=sig.cand6; psi.array[9,,]=sig.cand6/10
sig.array[10,,]=sig.cand3; psi.array[10,,]=sig.cand2 #
sig.array[11,,]=sig.cand5; psi.array[11,,]=sig.cand2  
sig.array[12,,]=sig.cand3; psi.array[12,,]=sig.cand4

ndat = 200   # Number of datasets at each covariance setting
nimp = 60   # Number of imputations
nmat = 12
nit = 85   # Iterations for each imputation
m=15       # Number of studies
nvec = rep(30,m)  # Sample size per study
nindices=cbind(c(1,cumsum(nvec[-length(nvec)])+1),c(cumsum(nvec)))
p=3
N=sum(nvec)
x=NULL
for(k in 1:length(nvec)){ x=c(x,rep(k,nvec[k]))}
D=data.frame(o=rep(1,N),x=as.factor(x))
X=model.matrix(~0+as.factor(x))
jn=X%*%t(X)
zi = as.matrix(rnorm(N))

# Array to hold parameter estimates from all imputations
betaALL=array(NA,dim=c(nmat,ndat,25,4))

for(r in 1:nmat){

  E=sig.array[r,,]
  psi=psi.array[r,,]
  P = psi
  n1 = nvec[1]

  betaest=array(NA,dim=c(ndat,25,4))

  #for( l in 1:ndat){
  params_thisr <- foreach( l = 1:ndat) %dopar%{
  #params_thisr <-lapply(1:21, function(l){  
    
    library("mice")  # Reload library when using "dopar"
    library("pan")
    library("MASS")
    library("lme4")
    eps=mvrnorm(N,rep(0,p),Sig=E)
    t=mvrnorm(m,rep(0,p),Sig=psi)
    y1=eps[,1]+X%*%(t[,1])*zi
    y2=eps[,2]+X%*%(t[,2])*zi
    y3= eps[,3]+X%*%(t[,3])*zi
    y1.zi=X%*%t(X)%*%(y1*zi)
    y2.zi=X%*%t(X)%*%(y2*zi)
    y3.zi=X%*%t(X)%*%(y3*zi)

    y.full=cbind(y1,y2)
    y1=y.full[,1]
    y2=y.full[,2]
    mind.1=1:(nindices[8,2])
    mind.2=nindices[9,1]:nindices[12,2]
    m1.vec=rep(0,m*nvec[1])
    m2.vec=m1.vec
    m1.vec[mind.1]=1
    m2.vec[mind.2]=1
    m.v1=length(unique(x[-mind.1])); m.v2=length(unique(x[-mind.2]))
    xm1=factor(as.numeric(x[-mind.1]))
    xm2=as.factor(as.numeric(x[-mind.2]))
    x=as.factor(x)
    jn21=(model.matrix(~0+xm1))%*%t(model.matrix(~0+xm1))
    jn22=(model.matrix(~0+xm2))%*%t(model.matrix(~0+xm2))
    
    ZZt = zi%*%t(zi)
    pcol=rep(0,length(y1))
    pcol[mind.1]=1; pcol[mind.2]=2
    y1[mind.1]=NA
    y2[mind.2]=NA
    y1.zi[mind.1]=NA
    y2.zi[mind.2]=NA
    y.tot=cbind(y1,y1.zi,y2,y2.zi,y3,as.numeric(x),zi,rep(1,length(y1)))
    y.tot2 = cbind(y1,y2,as.numeric(x),zi,rep(1,length(y1)))

    # MICE-ML imputation
    mice.compREML = mice.ZRR(y1.dat = y1,y2.dat = y2,X.dat = as.matrix(y3) ,x.fact = x,z = zi , n.imp = nimp, n.it = nit)
    
    # MICE-IW imputation
    init=mice(cbind(y3,y.tot2),nit=0)
    pred1=init$pred
    pred1[2,]=c(1,0,1,-2,2,1)
    pred1[3,]=c(1,1,0,-2,2,1)
    pred2 = pred1
    pred2[2,]=c(1,0,3,-2,2,1)
    pred2[3,]=c(1,3,0,-2,2,1)
    
    impm1=mice(cbind(y3,y.tot2),predictorMatrix=pred2,m=nimp,method=c("","2l.pan","2l.pan","","",""),maxit=nit, print=FALSE)   #MICE-IW compatible
    
    impm2=mice(cbind(y3,y.tot2),predictorMatrix=pred1,m=nimp,method=c("","2l.pan","2l.pan","","",""),maxit=nit,print=FALSE)   # MICE-IW
    
    y1.mice=impm1$imp$y1
    y2.mice=impm1$imp$y2
    pan.comp1=array(NA,dim=c(nimp,dim(y.full)))
    pan.comp2=pan.comp1
    pan.comp3=pan.comp2
    for(j in 1:nimp)
    {
      pan.comp1[j,,]=y.full
      pan.comp1[j,mind.1,1]=y1.mice[,j]
      pan.comp1[j,mind.2,2]=y2.mice[,j]
    }
    
    y1.mice2=impm2$imp$y1
    y2.mice2=impm2$imp$y2
    for(j in 1:nimp)
    {
      pan.comp2[j,,]=y.full
      pan.comp2[j,mind.1,1]=y1.mice2[,j]
      pan.comp2[j,mind.2,2]=y2.mice2[,j] 
    }
    
    pri=list(a=2,Binv=diag(rep(1,2)),c=2,Dinv=diag(rep(1,2)))
    
    for( j in 1:nimp)
    {
      imp3=pan(y.tot[,c(1,3)],subj = x,y.tot[,c(5,7,8)],xcol=c(1,3),zcol=2,prior=pri,seed=round(runif(1, 1, 10^7)), iter=20000)
      pan.comp3[j,,]=imp3$y  
    }
    
    TEMP = matrix(NA,nrow=5*5,ncol=4)
    TEMP[c(1,6,11,16,21),]=beta2.fulldata.rslopes.Ximputed(y.full,y3,x=x,XM=NULL,zi)
    TEMP[c(2,7,12,17,22),]=beta2.rslopes.Ximputed(pan.comp1,Yvar = y3 ,x,XM=NULL,zi)
    TEMP[c(3,8,13,18,23),]=beta2.rslopes.Ximputed(pan.comp2,Yvar = y3 ,x,XM=NULL,zi)
    TEMP[c(4,9,14,19,24),]=beta2.rslopes.Ximputed(pan.comp3,Yvar = y3 ,x,XM=NULL,zi)
    TEMP[c(5,10,15,20,25),]=beta2.rslopes.Ximputed(mice.compREML,Yvar = y3 ,x,XM=NULL,zi)
    
    betaest[l,,]=TEMP

   TEMP
  } 

   for( j in 1:ndat)
   {
     betaALL[r,j,,] =params_thisr[[j]][j,,] 
   }
}

