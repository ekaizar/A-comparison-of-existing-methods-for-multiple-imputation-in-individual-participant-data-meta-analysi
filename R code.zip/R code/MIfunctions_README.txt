
# =============================================
# 2017-03_MIfunctions.R  contents
# These functions perform imputation and analysis for
# simulated datasets
# =============================================


1. mice.RR
	Function: performs MI using the MICE-ML method with random intercepts 

	Arguments: y1.dat,y2.dat,X.dat,x.fact,n.imp, n.it = 35
		y1.dat, y.2dat : vectors that have missing values
		X.dat : matrix of (fully observed) fixed effects 
		x.fact : vector (of factors) containing study indicators
		n.it : number of iterations

2. mice.ZRR

	Function: performs MI using the MICE-ML method with random slope

	Arguments: y1.dat,y2.dat,X.dat,x.fact,z, n.imp, n.it = 35
		y1.dat, y.2dat : vectors that have missing values
		X.dat : matrix of (fully observed) fixed effects 
		x.fact : vector (of factors) containing study indicators
		z : random effect vector
		n.it : number of iterations


3. cov.var.re
	: find asymptotic covariance of (sigma, psi) evaluated at estimates

	Arguments: shat, dhat, n.vec
		shat : ML estimate of sigma
		dhat : ML estimate of psi
		n.vec: vector of study sample sizes

4.  cov.var.reZ
	: find asymptotic covariance of (sigma, psi) evaluated at estimates for random slopes model
	
	Arguments: shat, dhat, n.vec
		shat : ML estimate of sigma
		dhat : ML estimate of psi
		n.vec: vector of study sample sizes
		Z: random slope covariate

5.  beta2.fulldata.Ximputed
	: get parameter estimates for random intercepts analysis model, when full data is used

	Arguments: full, r.col, x, XM = NULL
		full : matrix of full data
		r.col : number indicating which column is the response variable
		x : factor indicating study
		XM : fixed effects matrix


	Value: a 5 x 4 matrix.  Rows are the parameters of the model. Columns 1 and 2 are point estimate
	and standard error.  Columns 3 and 4 are NA.


6.  beta2.Ximputed
	: get parameter estiamtes for random intercepts analysis model, given array of imputed datasets

	Arguments: imp.array, Yvar, x, XM, impname
		imp.array : nimp x n x 2 array of imputed datasets.
		Yvar: vector containing the response variable
		x: factor indicating study
		XM: fixed effects matrix
		
	Value: a 5 x 4 matrix containing averages over all imputations.  Rows are parameters of the model, 
	Col 1 is point estimate, 2 is average st error,
	3 is across-imputation std error, and 4 is total std error calculated with Rubin's rules.

7.  beta2.fulldata.rslopes.Ximputed

	Arguments: full,q,x,XM=NULL, Z
		full : matrix of full data
		q : column of full that contains response variable
		x: factor with study indicators
		XM: fixed effects matrix
		Z:  random slope covariate


	Value: 5 x 4 matrix. Each row is a parameter, col 1 is point estimate, col 2 is standard error.

8.  beta2.rslopes.Ximputed

	Argument: imp.array,Yvar,x,XM=NULL,Z,impname=NULL
		imp.array: nimp x N x 2 array of imputed datasets
		Yvar: vector containing the response variable
		x : factor indicating study
		XM: matrix of fixed effects
		Z: random slope covariate

	Value: a 5 x 4 matrix containing averages over all imputations.  Rows are parameters of the model, 
	Col 1 is point estimate, 2 is average st error,
	3 is across-imputation std error, and 4 is total std error calculated with Rubin's rules.


