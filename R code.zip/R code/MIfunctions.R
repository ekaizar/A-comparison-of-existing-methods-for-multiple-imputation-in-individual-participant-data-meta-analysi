

## =================================================
##  function for RR MICE
## =================================================

mice.RR = function(y1.dat,y2.dat,X.dat,x.fact,n.imp, n.it = 35)
{
  # y1.dat, y2.dat are variables to be imputed
  # X.dat is X matrix of fixed covariates
  # x.fact is factor vector of study indicators
  badvar = 0
  y1f = y1.dat
  y2f = y2.dat
  N = length(y1.dat)
  m = length(unique(x.fact))
  Xm = model.matrix(~0+as.factor(x.fact))
  nvec = diag( t(Xm)%*%Xm )

  y1fbar = Xm%*%t(Xm)%*%y1f
  y2fbar = Xm%*%t(Xm)%*%y2f

  mind.1 = which(is.na(y1.dat))
  mind.2 = which(is.na(y2.dat))
  m.v1=length(unique(x.fact[-mind.1])); m.v2=length(unique(x.fact[-mind.2]))
  xm1=factor(as.numeric(x.fact[-mind.1]))
  xm2=as.factor(as.numeric(x.fact[-mind.2]))
  #x=as.factor(x.fact)
  jn21=(model.matrix(~0+xm1))%*%t(model.matrix(~0+xm1))
  jn22=(model.matrix(~0+xm2))%*%t(model.matrix(~0+xm2))

  

impfREML1=matrix(NA,nrow=n.imp,ncol=length(mind.1))
impfREML2=matrix(NA,nrow=n.imp,ncol=length(mind.2))

####################################
# this function just uses REML
####################################
for(j in 1:n.imp){
  
  y2f[mind.2] = y2f[sample((1:N)[-mind.2],length(mind.2),replace=T)] # inititialize missing y1s

  for(k in 1:n.it){
    
    y2fbar=Xm%*%t(Xm)%*%y2f
    X.2 = cbind(rep(1,length(y2f)),y2f,y2fbar)
    
    if ( ! is.null(X.dat)){
        X.2 = cbind(X.2,X.dat) }
    
    fitw.R=lmer(y1f[-mind.1]~X.2[-mind.1,-1]+(1|xm1),REML=T,InstEval,
     control = lmerControl(calc.derivs = FALSE))# intercept already included; don't put it here
    
    s.hat.R=attr(VarCorr(fitw.R),"sc")^2
    p.hat.R=as.numeric(VarCorr(fitw.R)$x)
    
    # dist of betahat
    varhat.R=s.hat.R*diag(length(y1f[-mind.1]))+p.hat.R*jn21
    beta.hat.R=fixef(fitw.R)
    var.betahat.R=solve( t(X.2[-mind.1,])%*%solve(varhat.R)%*%X.2[-mind.1,] )
    beta.tilde.R=mvrnorm(1,beta.hat.R,var.betahat.R)
    
    var.sphat.R=cov.var.re(sqrt(s.hat.R),sqrt(p.hat.R),n.vec=nvec)
    pd=sum(eigen(var.sphat.R)$values<0)==0
    if(!pd)
    {
      badvar = 0
      var.newR=c(s.hat.R,p.hat.R) # following RR, use improper imp if not PD
    } else{
      success=0
      while(success==0)
      {
        var.newR=mvrnorm(1,c(s.hat.R,p.hat.R),var.sphat.R)
        if(var.newR[1]>0 & var.newR[2]>0){success=1} else{ badvar = badvar+1 }
      }
    }
    
    #################################
    # generate imputations
    eps.imp=rnorm(length(mind.1),0,sqrt(var.newR[1]))
    t.imp=rep(0,m)
    t.imp[-as.numeric(levels(xm1))]=rnorm(m-m.v1,0,sqrt(var.newR[2]))
    y1.imp=X.2[mind.1,]%*%beta.tilde.R+eps.imp+Xm[mind.1,]%*%t.imp
    y1f[mind.1]=y1.imp
    
    ################################################## y2
    y1fbar=Xm%*%t(Xm)%*%y1f
    X.1=cbind(rep(1,length(y1f)),y1f,y1fbar)
    
    if ( !is.null(X.dat)){
        X.1=cbind(X.1,X.dat)  }
    
    fitw.R=lmer(y2f[-mind.2]~X.1[-mind.2,-1]+(1|xm2),REML=T,InstEval,
     control = lmerControl(calc.derivs = FALSE))
    
    s.hat.R=attr(VarCorr(fitw.R),"sc")^2
    p.hat.R=as.numeric(VarCorr(fitw.R)$x)
    
    # dist of betahat
    varhat.R=s.hat.R*diag(length(y1f[-mind.2]))+p.hat.R*jn22
    beta.hat.R=fixef(fitw.R)
    var.betahat.R=solve(t(X.1[-mind.2,])%*%solve(varhat.R)%*%X.1[-mind.2,])
    beta.tilde.R=mvrnorm(1,beta.hat.R,var.betahat.R)
    
    var.sphat.R=cov.var.re(sqrt(s.hat.R),sqrt(p.hat.R),n.vec=nvec)
    pd=sum(eigen(var.sphat.R)$values<0)==0
    if(!pd)
    {
      badvar = badvar + 1
      var.newR=c(s.hat.R,p.hat.R) # following RR use improper imp if not PD
    } else{
      success=0
      while(success==0)
      {
        var.newR=mvrnorm(1,c(s.hat.R,p.hat.R),var.sphat.R)
        if(var.newR[1]>0 & var.newR[2]>0){success=1}  else{badvar = badvar + 1}
      }
    }
    
    #####################
    # imputations for y2
    eps2.imp=rnorm(length(mind.2),0,sqrt(var.newR[1]))
    t2.imp=rep(0,m)
    t2.imp[-as.numeric(levels(xm2))]=rnorm(m-m.v2,0,sqrt(var.newR[2]))
    y2.imp=X.1[mind.2,]%*%beta.tilde.R+eps2.imp+Xm[mind.2,]%*%t2.imp
    y2f[mind.2]=y2.imp
  }
  impfREML1[j,]=as.numeric(y1.imp)
  impfREML2[j,]=as.numeric(y2.imp)
}

  mice.compREML=array(NA,dim=c(nimp,length(y1f),2))
  for(k in 1:nimp){
    mice.compREML[k,,]=cbind(y1.dat,y2.dat)
    mice.compREML[k,mind.1,1]=impfREML1[k,]
    mice.compREML[k,mind.2,2]=impfREML2[k,] }
  
  return(list(mice.compREML, badvar))
}

# =================================
# MICE RR for random slopes
# =================================

mice.ZRR = function(y1.dat,y2.dat,X.dat,x.fact,z, n.imp, n.it = 35)
{
  # y1.dat, y2.dat are variables to be imputed
  # X.dat is X matrix of fixed covariates
  # x.fact is factor vector of study indicators
  
  y1f = y1.dat
  y2f = y2.dat
  

  N = length(y1.dat)
  m = length(unique(x.fact))
  Xm = model.matrix(~0+as.factor(x.fact))
  nvec = diag( t(Xm)%*%Xm )
  
  
  y1.zi=Xm%*%t(Xm)%*%(y1*zi)
  y2.zi=Xm%*%t(Xm)%*%(y2 *zi)
  y2f.zi=y2.zi
  y1f.zi=y1.zi


  mind.1 = which(is.na(y1.dat))
  mind.2 = which(is.na(y2.dat))
  m.v1=length(unique(x.fact[-mind.1])); m.v2=length(unique(x.fact[-mind.2]))
  xm1=factor(as.numeric(x.fact[-mind.1]))
  xm2=as.factor(as.numeric(x.fact[-mind.2]))
  #x=as.factor(x.fact)
  jn21=(model.matrix(~0+xm1))%*%t(model.matrix(~0+xm1))
  jn22=(model.matrix(~0+xm2))%*%t(model.matrix(~0+xm2))

  

impfREML1=matrix(NA,nrow=n.imp,ncol=length(mind.1))
impfREML2=matrix(NA,nrow=n.imp,ncol=length(mind.2))

####################################
# this function just uses REML
####################################
for(j in 1:n.imp){
  
  y2f[mind.2] = y2f[sample((1:N)[-mind.2],length(mind.2),replace=T)] # inititialize missing y1s
  
  for(k in 1:n.it){
    
    y2f.zi=X%*%t(X)%*%(y2f*zi)
    if ( !is.null(X.dat)){
    X.2=cbind(rep(1,length(y2f)),y2f,y2f.zi, X.dat)  }
    if ( is.null(X.dat)){
    X.2=cbind(rep(1,length(y2f)),y2f,y2f.zi)  }
    fitw.R=lmer(y1f[-mind.1]~X.2[-mind.1,-1]+(0+zi[-mind.1]|xm1),REML=T)
    s.hat.R=attr(VarCorr(fitw.R),"sc")^2
    p.hat.R=as.numeric(VarCorr(fitw.R)$x)
        
        # dist of betahat
    varhat.R=s.hat.R*diag(length(y1f[-mind.1]))+p.hat.R*(zi[-mind.1]%*%t(zi[-mind.1]))
    beta.hat.R=fixef(fitw.R)
    var.betahat.R=solve(t(X.2[-mind.1,])%*%solve(varhat.R)%*%X.2[-mind.1,])
    beta.tilde.R=mvrnorm(1,beta.hat.R,var.betahat.R)
    
       var.sphat.R=cov.var.reZ(sqrt(s.hat.R),sqrt(p.hat.R),n.vec=nvec,Z=zi)
        pd=sum(eigen(var.sphat.R)$values<0)==0
        if(!pd)
        {
          var.newR=c(s.hat.R,p.hat.R) # following RR use improper imp if not PD
        } else{
          success=0
          while(success==0)
          {
            var.newR=mvrnorm(1,c(s.hat.R,p.hat.R),var.sphat.R)
            if(var.newR[1]>0 & var.newR[2]>0){success=1}
          }
        }
    
        #################################
        # generate imputations
        eps.imp=rnorm(length(mind.1),0,sqrt(var.newR[1]))
        t.imp=rep(0,m)
        t.imp[-as.numeric(levels(xm1))]=rnorm(m-m.v1,0,sqrt(var.newR[2]))
        y1.imp=X.2[mind.1,]%*%beta.tilde.R+eps.imp+(X[mind.1,]%*%t.imp)*zi[mind.1,]
        y1f[mind.1]=y1.imp
    
         ################################################## y2
        y1f.zi=X%*%t(X)%*%(y1f*zi)
        
        if ( !is.null(X.dat)){
        X.1=cbind(rep(1,length(y1f)),y1f,y1f.zi, X.dat)  }
        if ( is.null(X.dat)){
        X.1=cbind(rep(1,length(y1f)),y1f,y1f.zi)  }
    
        fitw.R=lmer(y2f[-mind.2]~X.1[-mind.2,-1]+(0+zi[-mind.2,]|xm2),REML=T)
        
        s.hat.R=attr(VarCorr(fitw.R),"sc")^2
        p.hat.R=as.numeric(VarCorr(fitw.R)$x)
        
        # dist of betahat
        varhat.R=s.hat.R*diag(length(y1f[-mind.1]))+p.hat.R*zi[-mind.1]%*%t(zi[-mind.1,])
        beta.hat.R=fixef(fitw.R)
        var.betahat.R=solve(t(X.2[-mind.1,])%*%solve(varhat.R)%*%X.2[-mind.1,])
        beta.tilde.R=mvrnorm(1,beta.hat.R,var.betahat.R)
        
        var.sphat.R=cov.var.reZ(sqrt(s.hat.R),sqrt(p.hat.R),n.vec=nvec, Z=zi)
        pd=sum(eigen(var.sphat.R)$values<0)==0
        if(!pd)
        {
          var.newR=c(s.hat.R,p.hat.R) # following RR use improper imp if not PD
        } else{
          success=0
          while(success==0)
          {
            var.newR=mvrnorm(1,c(s.hat.R,p.hat.R),var.sphat.R)
            if(var.newR[1]>0 & var.newR[2]>0){success=1}
          }
        }
        
    #####################
    # imputations for y2
    eps2.imp=rnorm(length(mind.2),0,sqrt(var.newR[1]))
    t2.imp=rep(0,m)
    t2.imp[-as.numeric(levels(xm2))]=rnorm(m-m.v2,0,sqrt(var.newR[2]))
    y2.imp=X.1[mind.2,]%*%beta.tilde.R+eps2.imp+(X[mind.2,]%*%t2.imp)*zi[mind.2,]
    y2f[mind.2]=y2.imp
  }
  impfREML1[j,]=as.numeric(y1.imp)
  impfREML2[j,]=as.numeric(y2.imp)
}

  mice.compREML=array(NA,dim=c(n.imp,length(y1f),2))
  for(q in 1:n.imp){
    mice.compREML[q,,]=cbind(y1.dat,y2.dat)
    mice.compREML[q,mind.1,1]=impfREML1[q,]
    mice.compREML[q,mind.2,2]=impfREML2[q,] }
  
  mice.compREML
}

cov.var.re=function(shat,dhat,n.vec){
  N=sum(n.vec)
  V11=N*shat^(-4)
  V12=shat^(-2)*sum(n.vec/(1+n.vec*dhat))
  V22=sum((n.vec/(1+n.vec*dhat))^2)
  return(2*solve(matrix(c(V11,V12,V12,V22),nrow=2)))
  
}

cov.var.reZ=function(shat,dhat,n.vec,Z){
  
  # random effect covariance when Z is r.e. design
  normZ = sqrt(t(Z)%*%Z)
  N=sum(n.vec)
  V11=N*shat^(-4)
  V12=shat^(-2)*sum(normZ^2/(1+(normZ^2)*dhat))
  V22=sum(normZ^4/((1+normZ^2*dhat)^2) )
  return(2*solve(matrix(c(V11,V12,V12,V22),nrow=2)))
  
}



# ======================================
# Parameter estimates for random intercepts
# (Simulations 1-3,5)
# ======================================

# For the full data
beta2.fulldata.Ximputed=function(full,r.col,x,XM=NULL){

# r.col is the column containing response variable
  
  X=model.matrix( ~ 0 + x, XM)
  nvec=diag(t(X)%*%X)
  lm1=lmer(full[,r.col]~full[,-r.col]+(1|x))
  
  mi.comb = matrix(NA,nrow=5,ncol=4)
  
  vHat1=cov.var.re(sqrt(attr(VarCorr(lm1),"sc")^2),sqrt(as.numeric(VarCorr(lm1))),nvec)
  mi.comb[1:3,1:2]=cbind(fixef(lm1),sqrt(diag(vcov(lm1))))
  mi.comb[4,1:2] =c( attr(VarCorr(lm1),"sc")^2, sqrt(vHat1[1,1]))
  mi.comb[5,1:2] = c(as.numeric(VarCorr(lm1)),sqrt(vHat1[2,2]) )
  
  rownames(mi.comb)=paste(c("int.","betay.","betaysum.","error.","re."),rep("full",5),sep="")
  return(mi.comb)

}

# For array of imputed data
beta2.Ximputed=function(imp.array,Yvar,x,XM=NULL,impname=NULL){
  #the response variable is now Yvar!
  #both vars in imp.array will be covariates
  
  X=model.matrix( ~ 0 + x, XM)
  nvec=diag(t(X)%*%X)
 
  nimpp=dim(imp.array)[1]
  mi.comb = matrix(NA,nrow=5,ncol=4)
  mi.beta = array(NA,dim=c(nimpp,3,2))
  mi.sigma = matrix(NA,nrow=nimpp,ncol=2)
  mi.psi = matrix(NA,nrow=nimpp,ncol=2)
  
  for(k in 1:nimpp){
      if ( !is.null(XM)) { XTEMP = cbind(imp.array[k,,],XM) }
      if (is.null(XM))  { XTEMP = imp.array[k,,] }
      lm3=lmer( Yvar ~XTEMP+(1|x))
      vHat3=cov.var.re(sqrt(attr(VarCorr(lm3),"sc")^2),sqrt(as.numeric(VarCorr(lm3))),nvec)
      mi.beta[k,,]=cbind(fixef(lm3),sqrt(diag(vcov(lm3))))
      mi.sigma[k,] =c( attr(VarCorr(lm3),"sc")^2, sqrt(vHat3[1,1]))
      mi.psi[k,] = c(as.numeric(VarCorr(lm3)),sqrt(vHat3[2,2]) )
  }
  ######################
  # combine rows to get MI ests
  
  mi.comb[1:3,1:3] =c(apply(mi.beta,2:3,mean),apply(mi.beta[,,1],2,sd))
  mi.comb[4,1:3] = c(apply(mi.sigma,2,mean),sd(mi.sigma[,1]))
  mi.comb[5,1:3] = c(apply(mi.psi,2,mean),sd(mi.psi[,1]))
  
  # fourth col for between-imp
  mi.comb[,4] = sqrt( mi.comb[,2]^2+mi.comb[,3]^2*(1+1/nimpp) )
  

  rownames(mi.comb)=paste(c("int.","betay1.","betay2.","error.","re."),impname,sep="")
  return(mi.comb)
}

# ======================================
# Parameter estimates for random slopes
# (Simulation 4)
# ======================================

# For array of imputed data
beta2.rslopes.Ximputed=function(imp.array,Yvar,x,XM=NULL,Z,impname=NULL){
  
  X=model.matrix( ~ 0 + x, XM)
  nvec=diag(t(X)%*%X)
  
  nimpp=dim(imp.array)[1]
  mi.comb = matrix(NA,nrow=5,ncol=4)
  mi.beta = array(NA,dim=c(nimpp,3,2))
  mi.sigma = matrix(NA,nrow=nimpp,ncol=2)
  mi.psi = matrix(NA,nrow=nimpp,ncol=2)
  
  for(k in 1:nimpp){
    if ( is.null(XM)){
      Xtemp = imp.array[k,,]}
    if (!is.null(XM)){
      Xtemp = cbind(imp.array[k,,],XM)}
    lm3=lmer(Yvar~Xtemp+(0+Z|x))
    vHat3=cov.var.reZ(sqrt(attr(VarCorr(lm3),"sc")^2),sqrt(as.numeric(VarCorr(lm3))),nvec, Z)
    mi.beta[k,,]=cbind(fixef(lm3),sqrt(diag(vcov(lm3))))
    mi.sigma[k,] =c( attr(VarCorr(lm3),"sc")^2, sqrt(vHat3[1,1]))
    mi.psi[k,] = c(as.numeric(VarCorr(lm3)),sqrt(vHat3[2,2]) )
  }
  
  # combine rows to get MI ests
  
  mi.comb[1:3,1:3] =c(apply(mi.beta,2:3,mean),apply(mi.beta[,,1],2,sd))
  mi.comb[4,1:3] = c(apply(mi.sigma,2,mean),sd(mi.sigma[,1]))
  mi.comb[5,1:3] = c(apply(mi.psi,2,mean),sd(mi.psi[,1]))
  
  # fourth col for between-imp
  mi.comb[,4] = sqrt( mi.comb[,2]^2+mi.comb[,3]^2*(1+1/nimpp) )
  
  
  rownames(mi.comb)=paste(c("int.","betay.","betaysum.","error.","re."),impname,sep="")
  return(mi.comb)
}

# For the full data
beta2.fulldata.rslopes.Ximputed=function(full,Yvar,x,XM=NULL, Z){
  
  X=model.matrix( ~ 0 + x, XM)
  nvec=diag(t(X)%*%X)
  if ( is.null(XM)){
    Xtemp = full}
  if ( !is.null(XM)){
    Xtemp = cbind(full,XM)}
  lm1=lmer(Yvar~Xtemp+(0+Z|x))
  
  mi.comb = matrix(NA,nrow=5,ncol=4)
  
  vHat1=cov.var.reZ(sqrt(attr(VarCorr(lm1),"sc")^2),sqrt(as.numeric(VarCorr(lm1))),nvec, Z)
  mi.comb[1:3,1:2]=cbind(fixef(lm1),sqrt(diag(vcov(lm1))))
  mi.comb[4,1:2] =c( attr(VarCorr(lm1),"sc")^2, sqrt(vHat1[1,1]))
  mi.comb[5,1:2] = c(as.numeric(VarCorr(lm1)),sqrt(vHat1[2,2]) )
  
  rownames(mi.comb)=paste(c("int.","betay.","betaysum.","error.","re."),rep("full",5),sep="")
  return(mi.comb)
  
}
