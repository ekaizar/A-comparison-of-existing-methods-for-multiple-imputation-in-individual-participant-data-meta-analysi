# ==========================
# Marc h6: summary of "Simulation A"
# ==================================

rm(list=ls())
library("xtable")
source("U:\\PlotMiceEsts.R")
setwd("U:\\2017-03 New Simulations")
setwd("~/2017-03 New Simulations/")
betaest_15 = array(NA, dim=c(16,200,25,4))
betamean_15 = array(NA, dim=c(16,25,4))

# Combine results into single array
for( r in 1:12)
{
  for( j in 1:ndat)
  {
    betaest_15[r,j,,] =betaALL[r,j,,]
  }
}


for( r in 1:12){
betamean_15[r,,] = apply(betaest_15[r,,,],2:3,mean)
}

q=which(!is.na(betamean_15[,1,1]))

# =================================================
# Load this function to for plots of estimates
# =================================================

plot.ests5 = function(est.array,setin,which.rows,axis.labels=NULL,plotmain=NULL,param.name=NULL,
                      legendtext=NULL,title=0){
  
  range.lower = min(est.array[setin,which.rows[1],1]-2*est.array[setin,which.rows[1],2], 
                    est.array[setin,which.rows[2],1]-2*est.array[setin,which.rows[2],4],
                    est.array[setin,which.rows[3],1]-2*est.array[setin,which.rows[3],4],
                    est.array[setin,which.rows[4],1]-2*est.array[setin,which.rows[4],4],
                    est.array[setin,which.rows[5],1]-2*est.array[setin,which.rows[5],4])
  
  
  range.upper = max(est.array[setin,which.rows[1],1]+2*est.array[setin,which.rows[1],2], 
                    est.array[setin,which.rows[2],1]+2*est.array[setin,which.rows[2],4],
                    est.array[setin,which.rows[3],1]+2*est.array[setin,which.rows[3],4],
                    est.array[setin,which.rows[4],1]+2*est.array[setin,which.rows[4],4],
                    est.array[setin,which.rows[5],1]+2*est.array[setin,which.rows[5],4])
  if(range.lower < 0 ) ylowlim = range.lower * 1.15 else ylowlim = range.lower*.85
  yhighlim = range.upper*1.05
  
  title1 = paste("Estimates for ",param.name," \n",plotmain)
  title2 = paste(plotmain)
  
  if( title == "main" ){
    title1 = title2
  }
  plot((1:length(setin))-.25,est.array[setin,which.rows[1],1],pch=19,cex=.75,ylim=c(ylowlim,yhighlim),xlim=c(-1.25,length(setin))+.6,
       ylab=expression(psi),xaxt="n", xlab="Setting",
       main=title1)
  axis(side=1,at=1:length(setin),labels=setin,cex.lab=.25,cex=.5, tick=FALSE)
  if(!is.null(axis.labels)){ axis(side=1,at=setin,labels=axis.labels,cex.lab=.25,cex=.5) }
  segments((1:length(setin))-.25,est.array[setin,which.rows[1],1]-2*est.array[setin,which.rows[1],2],(1:length(setin))-.25,
           est.array[setin,which.rows[1],1]+2*est.array[setin,which.rows[1],2],lty=1)
  
  # joint model, 4th row
  points((1:length(setin))-.15,est.array[setin,which.rows[4],1],pch=15,cex=.75,lty=1,lwd=2,col="azure4")
  segments((1:length(setin))-.15,est.array[setin,which.rows[4],1]-2*est.array[setin,which.rows[4],4],(1:length(setin))-.15,
           est.array[setin,which.rows[4],1]+2*est.array[setin,which.rows[4],4],lty=1,col="azure4")
  # regular mice, 3rd row
  points((1:length(setin)),est.array[setin,which.rows[3],1],pch=18,cex=.75,lty=1,lwd=2,col="blue")
  segments((1:length(setin)),est.array[setin,which.rows[3],1]-2*est.array[setin,which.rows[3],4],(1:length(setin)),
           est.array[setin,which.rows[3],1]+2*est.array[setin,which.rows[3],4],lty=1,col="blue")
  
  # compatible mice, 2nd row
  points((1:length(setin))+.15,est.array[setin,which.rows[2],1],pch=18,cex=.75,lty=2,lwd=2,col="darkgreen")
  segments((1:length(setin))+.15,est.array[setin,which.rows[2],1]-2*est.array[setin,which.rows[2],4],(1:length(setin))+.15,
           est.array[setin,which.rows[2],1]+2*est.array[setin,which.rows[2],4],lty=2,col="darkgreen")
  
  # mice ML
  points((1:length(setin))+.25,est.array[setin,which.rows[5],1],pch=17,cex=.75,lty=3,lwd=2,col="purple")
  segments((1:length(setin))+.25,est.array[setin,which.rows[5],1]-2*est.array[setin,which.rows[5],4],(1:length(setin))+.25,
           est.array[setin,which.rows[5],1]+2*est.array[setin,which.rows[5],4],lty=3,col="purple")
  if (is.null(legendtext)) {
    legend(x=-.6,y=yhighlim,legend=c("full data","joint","mice IW","mice IW-c","mice ML"),lty=c(1,1,1,2,2),pch=c(19,15,18,18,17),col=c(1,"azure4","blue","darkgreen","purple"),
           lwd=1.6,bty="n",cex=.9)
  }
  else {
    legend("topleft",legend=legendtext,lty=c(1,3,3,2,2),col=c(1,"darkgreen","blue","azure4","purple"),
           cex=.85,lwd=2.2)
  }
}

# ========================================
# Create plots of estimates
# =========================================

p.main1 = "Simulation 3"  # Title of plot
# Creates plots of different parameter estiamtes
plot.ests5(betamean_15,setin=q,c(21:25),plotmain=p.main1,param.name="psi",title="main")
plot.ests5(betamean_15,setin=q,c(6:10),plotmain=p.main1,param.name="beta1",title="main")
plot.ests5(betamean_15,setin=q,c(11:15),plotmain=p.main1,param.name="beta2",title="main")
plot.ests5(betamean_15,setin=q,c(16:20),plotmain=p.main1,param.name="sigma",title="main")

# Generates Latex table of parameter estimates
for( r in 1:12){
TEMP.data = betamean_15[r,,]
TEMP.data[c(1,6,11,16,21),4] = TEMP.data[c(1,6,11,16,21),2]
TEMP.data = TEMP.data[,c(1,4)]
colnames(TEMP.data) = c("Estimate", "std error")
TEMP.data = paste(formatC(TEMP.data[,1],format="f",digits=3), "(",formatC(TEMP.data[,2],format="f",digits=2),")")

TEMP2 = matrix(TEMP.data,nrow=5)
TEMP2 = TEMP2[c(1,4,3,2,5),]
colnames(TEMP2) = c("$\\beta_0$", "$\\beta_1$","$\\beta_2$","$\\sigma$", "$\\psi$")
rownames(TEMP2) = c("Full data", "Joint" , "MICE-IW" ,"MICE-IW-c", "MICE-ML")

title = paste("Covariance setting 3: rho1 = ", sig.array[r,1,2]/sqrt( sig.array[r,1,1]*sig.array[r,2,2] ),
  "\n rho2 = " , sig.array[r,1,2]/sqrt( psi.array[r,1,1]*psi.array[r,2,2] ) )

table = xtable(TEMP2)
print(xtable(TEMP2, caption = paste("Simulation 3; setting ",r)), caption.placement = 'top', 
	table.placement = 'H',sanitize.colnames.function = identity)

}

# Generates table of just Psi for all settings
Temp.psi= betamean_15[1:12, 21:25,c(1,4)] 
Temp.psi[,1,2] = betamean_15[1:12,21,2]
TEMP.psi = matrix(NA,nrow=5,ncol=12)
for( j in 1:5){
TEMP.psi[j,] = paste(formatC(Temp.psi[,j,1],format="f",digits=3)," ", "(",formatC(Temp.psi[,j,2],format="f",digits=2),")", sep="")
}

TEMP.psi = TEMP.psi[c(1,4,3,2,5),]

colnames(TEMP.psi) =1:12
rownames(TEMP.psi) = c("Full data", "Joint" , "MICE-IW" ,"MICE-IW-c", "MICE-ML")
TEMP.psi = t(TEMP.psi)

xtable(TEMP.psi)



