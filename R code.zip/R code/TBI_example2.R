
# =========================================
# TBI example 2   - Revised March 2017
# Hollingshead index for pTBI (pseudo studies 1,2,3)
# and z-ses (artificial missingness imposed on pseduo-study 4)
# CBC internalizing score is the response
# ==================================================
 
load("TBI_2016-08.Rdata")
source('TBI_example_functions.R')

library("mice")
library("pan")
library("MASS")
library("lme4")
library("xtable")
library("abind")

factor=as.factor(tbi[,3]*tbi[,11]) # indicator of psuedostudy

#########################
# pseudo study key:
# factor 1 : study1, site1
# factor 2 : study1, site 2
# factor 3 : study1, site 3
# facotr 4 : study2, site 2
# factor 6 : study2, site 3


basecol=c(4,12,14,16,17)  # group, sex, ageatinjury, age, race, maternal ed
tbi$group[which(tbi$group==3 | tbi$group ==4 )] = 2   # combine mild, moderate, and mild complicated groups 
ptbi.ind = which(tbi$study==1)
tbi[ptbi.ind,32] = tbi[ptbi.ind,31]  # combine Zses for pTBi and TBI

t2 = dirty.data(tbi,c(basecol,30,32,178),visitn=3, groups = 1:4)   # only include groups 1:4 (no control group) and visit 3
X_group = model.matrix( ~0 + as.factor(t2$tbi[,1]))[,-1]

# Matrix of all response and predictor variables, study indicators
y.tot2 = cbind(X_group,t2$tbi[,c(2:5,8,6:7)],as.numeric(t2$factor),rep(1,length(t2$factor)))
fact.col=dim(y.tot2)[2]-1 # where the factor falls in the dataframe
y.nomiss = y.tot2
fact.nomiss = t2$factor

ps1=which(y.tot2[,fact.col]==1)    # indices where each pseudo-study is
ps2=which(y.tot2[,fact.col]==2)
ps3=which(y.tot2[,fact.col]==3)
ps4=which(y.tot2[,fact.col]==4)
ps5=which(y.tot2[,fact.col]==5)

nimp=85; nit = 200
frac.miss = matrix(NA, nrow=7, ncol=5)

# ================================
#  summaries of data used in Example 2
# ================================
library("xtable")
NArows = apply(y.tot2,1,nacol)
c_case = which(NArows == 0)
summary.table = matrix(NA, nrow = ncol(y.tot2[,1:8]), ncol=5)

for ( j in 1:ncol(y.tot2[,1:8]))
{
	c_case = which(!is.na(y.tot2[,j]))
	Q= paste(formatC(tapply(y.tot2[c_case,j],t2$factor[c_case],mean, na.rm=T),digits=3,format="f"), " (",formatC(tapply(y.tot2[c_case,j],t2$factor[c_case],sd, na.rm=T),digits=2,format="f"), ")", sep="")
	summary.table[j,] = Q
}

summary.table = as.data.frame(summary.table)
rownames(summary.table) = names(t2$tbi)[c(1:5,8,6:7)]
colnames(summary.table) = c("pTBI- Site 1", "pTBI - Site 2", "pTBI - Site 3",
	 "TBI - Site 2", "TBI - Site 3")
xtable(summary.table)

# ================================
# Estimates without artifical missingnes 
# ================================

init_f = mice(y.tot2, nit=0)
pred_f = init_f$pred

# Variables to be imputed are Maternal Ed, BSI, CBC
pred_f[5,] = c( rep(1,4),0,1,1,1,-2,1)   # mat ed
pred_f[6,] = c( rep(1,5),0,1,1,-2,1)     # BSI
pred_f[7,] = c( rep(1,6),0,1,-2,1)       # CBC ext

impm_f =mice(y.tot2,predictorMatrix=pred_f,m=nimp,method=c("","","","","2l.pan","2l.pan","2l.pan","","",""),maxit=55)
par(ask=T)
plot(impm_f)

m5 = which(is.na(y.tot2[,5])) 
m6 = which(is.na(y.tot2[,6])) 
m7 = which(is.na(y.tot2[,7])) 

# Combine estimates
f_completed_data = NULL
for( q in 1:nimp)
{
	f_completed_data = abind( f_completed_data, y.tot2, along=3)
	f_completed_data[m5,5,q] =  impm_f$imp[[5]][,q]
	f_completed_data[m6,6,q] =   impm_f$imp[[6]][,q]
	f_completed_data[m7,7,q] =   impm_f$imp[[7]][,q]
}

# Obtain parameter estimates
# Output is a list containing pooled estimates (item 1) and estimates for 
# each imputation (item 2)
fulldata.est_covariates_temp = analyze_TBI_imp_2(f_completed_data, 6,x_fact = fact.nomiss, x_cols = c(1:5,7))
fulldata.est_covariates = fulldata.est_covariates_temp[[1]]

ptemp = pool( as.mira(fulldata.est_covariates_temp[[2]]))
frac.miss[,1] = ptemp$fmi

# ====================================================
# Analysis with artificial missingness in Zses (column 8 of y.tot2)
# =====================================================

# generate missingness in zses
y.tot2[ps4,8] = NA


     m5 = which(is.na(y.tot2[,5])) 
     m6 = which(is.na(y.tot2[,6])) 
     m7 = which(is.na(y.tot2[,7])) 
     m8 = which(is.na(y.tot2[,8])) 

# ================================
# MICE - IW
# ================================

init=mice(y.tot2,nit=0)
pred1=init$pred
pred1[5,]=c(rep(1,4),0,1,1,1,-2,1)
pred1[6,]=c(rep(1,4),1,0,1,1,-2,1)
pred1[7,]=c(rep(1,4),1,1,0,1,-2,1)
pred1[8,]=c(rep(1,4),1,1,1,0,-2,1)

impm2=mice(y.tot2,predictorMatrix=pred1,m=nimp,method=c("","","","","2l.pan","2l.pan","2l.pan","2l.pan","",""),maxit=35)


miceiw_completed_data = NULL
for( q in 1:nimp)
{

	miceiw_completed_data = abind( miceiw_completed_data, y.tot2, along=3)
	miceiw_completed_data[m5,5,q] =  impm2$imp[[5]][,q]
	miceiw_completed_data[m6,6,q] =   impm2$imp[[6]][,q]
	miceiw_completed_data[m7,7,q] =   impm2$imp[[7]][,q]
	miceiw_completed_data[m8,8,q] =   impm2$imp[[8]][,q]
}



mice.iwR_temp = analyze_TBI_imp_2(miceiw_completed_data, 6,x_fact = fact.nomiss, x_cols = c(1:5,7) )
mice.iwR = mice.iwR_temp[[1]]

ptemp = pool( as.mira(mice.iwR_temp[[2]]) )
frac.miss[,3] = ptemp$fmi

# ================================
# MICE - ML
# ================================

miceML_imps =  MICE_ML2( fact.nomiss, y.tot2[,5:8], X.dat = y.tot2[,1:4],  nimp = nimp, n.it = 85)

miceML_completed_data = NULL
for( q in 1:(nimp))
{

	miceML_completed_data = abind( miceML_completed_data, y.tot2, along=3)
	miceML_completed_data[,5,q] =  miceML_imps[q,,1]
	miceML_completed_data[,6,q] =   miceML_imps[q,,2]
	miceML_completed_data[,7,q] =    miceML_imps[q,,3]
	miceML_completed_data[,8,q] =    miceML_imps[q,,4]

}

miceML_temp = analyze_TBI_imp_2(miceML_completed_data, 6,x_fact = fact.nomiss, x_cols = c(1:5,7))
miceML = miceML_temp[[1]]

ptemp = pool( as.mira(miceML_temp[[2]]) )
frac.miss[,5] = ptemp$fmi

# ==================================
# MICE IW compatible
# ==================================

init=mice(y.tot2,nit=0)
pred1=init$pred

pred1[5,] = c( rep(1,4),0,1,3,3,-2,1)   # mat ed
pred1[6,] = c( rep(1,4),1,0,3,3,-2,1)     # CBC
pred1[7,] = c( rep(1,4),1,1,0,3,-2,1)       # Hollingshead
pred1[8,] = c( rep(1,4),1,1,3,0,-2,1)         # Zses

impm_compat =mice((y.tot2),predictorMatrix=pred1,m=nimp,method=c("","","","","2l.pan","2l.pan","2l.pan","2l.pan","",""),maxit=55)

#par(ask=T)
#plot(impm_compat)
micecompat_completed_data = NULL
for( q in 1:nimp)
{

	micecompat_completed_data = abind( micecompat_completed_data, y.tot2, along=3)
	micecompat_completed_data[m5,5,q] =  impm_compat$imp[[5]][,q]
	micecompat_completed_data[m6,6,q] =   impm_compat$imp[[6]][,q]
	micecompat_completed_data[m7,7,q] =   impm_compat$imp[[7]][,q]
	micecompat_completed_data[m8,8,q] =   impm_compat$imp[[8]][,q]
}


mice.iw.compat_temp = analyze_TBI_imp_2(micecompat_completed_data, 6,x_fact = fact.nomiss, x_cols = c(1:5,7))
mice.iw.compat = mice.iw.compat_temp[[1]]

ptemp = pool( as.mira(mice.iw.compat_temp[[2]]) )
frac.miss[,4] = ptemp$fmi

# =======================================
# Joint model
# =======================================

pan.comp3X = array( NA, dim=c(nimp,dim(y.tot2[,5:8])))
pri=list(a=4,Binv=diag(rep(1,4)),c=4,Dinv=diag(rep(1,4)))

j = 1
for( j in 1:nimp)
{
  imp3X=pan(as.matrix(y.tot2[,c(5,6,7,8)]),as.factor(as.numeric(fact.nomiss)),pred=as.matrix(y.tot2[,c(1:4,10)]),xcol=c(1:5),zcol=5,prior=pri,seed=round(runif(1, 1, 10^7)),iter=30000)      # y.tot cols+1 is intercept
  pan.comp3X[j,1:184,1:4]=imp3X$y[1:184,1:4] 
}


joint_completed_data = NULL
for( q in 1:nimp)
{

	joint_completed_data = abind( joint_completed_data, y.tot2, along=3)
	joint_completed_data[m5,5,q] =  pan.comp3X[q, m5,5-4]
	joint_completed_data[m6,6,q] =   pan.comp3X[q, m6,6-4]
	joint_completed_data[m7,7,q] =   pan.comp3X[q, m7,7-4]
	joint_completed_data[m8,8,q] =   pan.comp3X[q,m8 ,8-4]
}


joint_temp = analyze_TBI_imp_2(joint_completed_data, 6,x_fact = fact.nomiss, x_cols = c(1:5,7))
joint = joint_temp[[1]]

ptemp = pool( as.mira(joint_temp[[2]]) )
frac.miss[,2] = ptemp$fmi

# ===============================================
# Table summarizing estimates
# ===============================================

library("xtable")

fulldata = matrix(NA,nrow=nrow(mice.iwR),ncol=5)
fulldata[,1] =as.matrix( paste(formatC(fulldata.est_covariates[,1],digits=3,format="f"),
	 " (",formatC(fulldata.est_covariates[,2],digits=3,format="f"), ")", sep="" ) )
fulldata[,2] = as.matrix( paste(formatC(mice.iwR[,1],digits=3,format="f"),
	 " (",formatC(mice.iwR[,4],digits=2,format="f"), ")", sep="" ) )
fulldata[,3] = as.matrix( paste(formatC(mice.iw.compat[,1],digits=3,format="f"),
	 " (",formatC(mice.iw.compat[,4],digits=2,format="f",preserve.width="common"), ")", sep="" ) )


fulldata[,4] =as.matrix( paste(formatC(miceML[,1],digits=3,format="f"),
	 " (",formatC(miceML[,4],digits=2,format="f"), ")", sep="" ) )
fulldata[,5] =as.matrix( paste(formatC(joint[,1],digits=3,format="f"),
	 " (",formatC(joint[,4],digits=2,format="f"), ")", sep="" ) )

fulldata = fulldata[,c(1,5,2:4)]
rownames(fulldata) = c("Intercept",c("Group")
,names(t2$tbi[,c(2:5, 6,7)]),"Error variance", "Random effect variance")
colnames(fulldata) = c("Observed data","MICE-IW", "MICE-IW (c) ", "MICE-ML", "Joint")[c(1,5,2:4)]
xtable(fulldata)
