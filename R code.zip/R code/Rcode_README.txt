
# =====================================================
# "A comparison of existing methods for multiple
# imputation in individual participant data meta-analysis"
# Contents of R code folder
# =====================================================

1. MIfunctions.R : functions used for imputation using MICE ML and for 
	estimating parameters of analysis models.  All simulation files 
	require these functions.

2. SimulationX_March2017.R: code for simulation studies 1-5 in the paper.

3. micemod_1.0.tar.gz, micemod_1.1.tar.gz : modified versions of the
	default "mice" package to change prior hyperparemeters.  All
	other aspects of the packages are identical to "mice". 

	micemod_1.0 : IW(1.6,1) prior on psi
	micemod_1.1 : IW(5,1) prior on psi

4. figures.R : code used to produce the in-text figure except simulation results.

5. Sim_figures.R: code used to produce plots and tables summarizing simulation results.

6. TBI_functions.R : functions required for analysis of TBI data.

7. TBI_example1.R, TBI_example2.R : code used for TBI examples 1 and 2, respectively