
setwd("U:\\2016-10 MICE paper")

# ==========================================
# this file contains code to make
# 1. plot of psi and beta as function of study size
# 2. density plots of joint and FCS IW priors
# 3. QQ plots
# ==========================================


# =====================================
# Figure 1: beta1.2,2 and psi1.2 as 
# functions of sample size
# =====================================

conditional.psi = function(P,E){  
  nvec = 1:175
  psi1.2 = P[1,1] - ( ( 2*E[1,2]*E[2,2]*P[1,2] - E[1,2]^2*P[2,2] + nvec*E[2,2]*P[1,2]^2 )/ 
                        ( E[2,2]*(E[2,2]+nvec*P[2,2]) ) )
  beta1.2 = P[1,2]/E[2,2] - ( (E[1,2]*P[2,2] + P[1,2]*P[2,2]*nvec)/ (E[2,2]*(E[2,2]+P[2,2]*nvec)))
  cbind(beta1.2,psi1.2)
}


p12 = 20
P3 = matrix(c(27, p12 , p12,33 ) , nrow=2) 
E3 = matrix(c(122, 87,87,147), nrow= 2)

rho=c(.9,.7,.1,-.3,-.9)
P3.a = array(NA,dim=c(length(rho),2,2))
P3.a[,1,1] = P3[1,1]; P3.a[,2,2] = P3[2,2];
P3.a[,1,2] = sqrt(P3[1,1]*P3[2,2])*rho 


a = conditional.psi(P3,E3)
a.array = array(NA,dim=c(length(rho),dim(a)))
for(j in 1:length(rho)){
a.array[j,,] = conditional.psi(P3.a[j,,],E3)
}

par(mfrow = c(1,2))
par(xpd=FALSE)
par(mar=c(5,5,3,2))
a.array[5,1:2,1] = -.15
a.array[5,1:2,1] = -.19

plot(1:175,a.array[1,,1], type="l", lwd = 2.4, xlab = "sample size", ylab = expression(beta["1.2,2"](n)), ylim=c(-.19,.05),
	cex.axis=1.35, cex.lab = 1.35)
for( j in (1:length(rho))){
 points(a.array[j,,1],type="l",lty=j, lwd=2.4)
}

legend("bottomright", legend=paste(rho,sep=","), lty=1:5, lwd=2.4,title="Correlation",xpd=TRUE,
	bty="n",cex=1.3)

plot(a.array[1,,2], type="l", lwd = 2.4, xlab = "sample size", ylab =  expression(psi["1.2"](n)), ylim=c(0,60.001),
	cex.lab=1.35, cex.axis = 1.35,lty=1)
for( j in (2:length(rho))){
 points(a.array[j,,2],type="l",lty=j,lwd=2.4)
}

dev.off()

# ===================================================
# multiplot function for ggplot
# ===================================================

multiplot <- function(..., plotlist=NULL, file, cols=1, layout=NULL) {
  # source: http://www.cookbook-r.com/Graphs/Multiple_graphs_on_one_page_(ggplot2)
  library(grid)

  # Make a list from the ... arguments and plotlist
  plots <- c(list(...), plotlist)

  numPlots = length(plots)

  # If layout is NULL, then use 'cols' to determine layout
  if (is.null(layout)) {
    # Make the panel
    # ncol: Number of columns of plots
    # nrow: Number of rows needed, calculated from # of cols
    layout <- matrix(seq(1, cols * ceiling(numPlots/cols)),
                    ncol = cols, nrow = ceiling(numPlots/cols))
  }

 if (numPlots==1) {
    print(plots[[1]])

  } else {
    # Set up the page
    grid.newpage()
    pushViewport(viewport(layout = grid.layout(nrow(layout), ncol(layout))))

    # Make each plot, in the correct location
    for (i in 1:numPlots) {
      # Get the i,j matrix positions of the regions that contain this subplot
      matchidx <- as.data.frame(which(layout == i, arr.ind = TRUE))

      print(plots[[i]], vp = viewport(layout.pos.row = matchidx$row,
                                      layout.pos.col = matchidx$col))
    }
  }
}

# ===================================================
# prior of joint and conditional priors on `phi' parameters
# ===================================================
library("ggplot2")
Lambda1 = as.matrix(diag(c(1,1)))

# samples from joint IW priors
E = array(NA,dim=c(2,2,10000))
P = array(NA, dim=c(2,2,10000))
for( j in 1:10000){
E[,,j] = solve(rWishart (1,2,Lambda1)[,,1])
P[,,j] = solve(rWishart (1,2,Lambda1)[,,1]) }

sig1.2 = E[1,1,]-(E[1,2,]^2)/E[2,2,]
n = 10
psi1.2 = P[1,1,] - ( ( 2*E[1,2,]*E[2,2,]*P[1,2,] - E[1,2,]^2*P[2,2,] + n*E[2,2,]*P[1,2,]^2 )/ ( E[2,2,]*(E[2,2,]+n*P[2,2,]) ) )
beta1.2 = P[1,2,]/E[2,2,] - ( (E[1,2,]*P[2,2,] + P[1,2,]*P[2,2,]*n)/ (E[2,2,]*(E[2,2,]+P[2,2,]*n)))
beta2.2 = E[1,2,]/E[2,2,]
beta2.1 = E[1,2,]/E[1,1,]
beta1.1 = P[1,2,]/E[1,1,] - ( (E[1,2,]*P[1,1,] + P[1,2,]*P[1,1,]*n)/ (E[1,1,]*(E[1,1,]+P[1,1,]*n)))

# samples from FCS IW priors
sig1.2FCS = 1/rWishart(10000,1,as.matrix(1))
psi1.2FCS = 1/rWishart(10000,1,as.matrix(1))

dens.fact =factor(c(rep(1,10000),rep(2,10000)), labels= c("joint prior", "fcs prior"))
sig.samples = as.data.frame(cbind( c(sig1.2,sig1.2FCS), dens.fact ))
psi.samples = as.data.frame(cbind( c(psi1.2,psi1.2FCS), as.factor(c(rep(1,10000),rep(2,10000))) ))
beta1.1samples = as.data.frame(cbind(c(beta1.1),factor(c(rep(1,10000)))))
beta2.1samples = as.data.frame(cbind(beta2.1,factor(rep(1,10000))))
my.labs = list("Joint", "FCS")

#Create plot
m <- ggplot(sig.samples, aes(x = V1)) + geom_density(aes(linetype=factor(c(rep("Joint",10000), rep("FCS",10000)))), size=1.4, alpha=.60) + scale_x_continuous(limits = c(0, 10))  + 
	scale_fill_manual("Prior",labels=c(my.labs), values=c("grey70","grey15")) + theme_bw() +
theme(legend.text = element_text( size = 14), legend.title = element_text(size = 14),
	axis.text = element_text(size=16),axis.title = element_text(size=16))+ xlab(expression( sigma[2.1])) +
 guides(linetype = guide_legend(title = "Prior", size=16)) 

m2 <- ggplot(psi.samples, aes(x = V1)) + geom_density(aes(linetype=factor(c(rep("Joint",10000), rep("FCS",10000)))),size=1.4) + scale_x_continuous(limits = c(0, 10)) + theme_bw() + scale_fill_discrete("Prior",labels=c(my.labs, "inv Wishart on psi2.1")) +
scale_fill_manual("Prior",labels=c(my.labs), values=c("grey70","grey15")) + theme_bw() +
theme(legend.text = element_text( size = 14), legend.title = element_text(size = 14),
	axis.text = element_text(size=16),axis.title = element_text(size=16))+ xlab(expression( psi[2.1])) +
 guides(linetype = guide_legend(title = "Prior", size=16)) 

m3 <- ggplot(beta1.1samples, aes(x = V1)) + geom_density(aes(linetype=factor(c(rep("Joint",10000)))),size=1.4) + scale_x_continuous(limits = c(-4.5, 4.5)) +
scale_fill_manual("Prior",labels=c(my.labs), values=c("grey70","grey15")) + theme_bw() + xlab(expression(beta["2.1,2"])) + theme_bw() +
theme(legend.text = element_text( size = 14), legend.title = element_text(size = 14),
	axis.text = element_text(size=16),axis.title = element_text(size=16)) +
 guides(linetype = guide_legend(title = "Prior", size=16)) 

m4 <- ggplot(beta2.1samples, aes(x = beta2.1)) + scale_color_grey() + geom_density(aes(linetype=factor(c(rep("Joint",10000)))), size=1.4) + scale_x_continuous(limits = c(-10, 10)) + xlab(expression(beta["2.1,1"])) +
scale_fill_manual("Prior",labels=c(my.labs)) + theme_bw() +
theme(legend.text = element_text( size = 14), legend.title = element_text(size = 14),
	axis.text = element_text(size=16),axis.title = element_text(size=16))+
 guides(linetype = guide_legend(title = "Prior", size=16)) 

multiplot(m,m4,m2,m3,cols=2)
dev.off()

# ======================================================
# QQ plots
# ======================================================

setwd("U:\\")
library("lme4")
library("MASS")
library("pan")

# set covariance
setseed(62116)

set.seed(6216)

E = matrix(c(122,85,85,150),nrow=2)/1.75
P = matrix(c(28,26,26,33),nrow=2)

set.seed(62816)
E = matrix(c(10,7.5, 7.5,  10), nrow = 2)
P = matrix(c(1,.25, .25, 10), nrow = 2)

n = 35
m = 30

x = kronecker(1:m, rep(1,n))
xmF = as.factor(x)
X = model.matrix(~0+as.factor(x))

eps = mvrnorm(n*m,c(0,0),E)
b = mvrnorm(m,c(0,0),P)

y1F = eps[,1] + X%*%b[,1]
y1barF = X%*%t(X)%*%y1F
y2F = eps[,2] +  X%*%b[,2]
y2barF = X%*%t(X)%*%y2F

s1 = array(NA, dim =c( 4,1500, 4) )
s2 = array(NA, dim =c( 4,1500, 4) )
nbig = 35
# change n and m to use a subset of the data
Matrix = cbind(c(10,35,10,35),c(5,5,30,30))

for( row in 1:4){
n = Matrix[row,1]
m =  Matrix[row,2]
subset=NULL
for( j in 1:m)
  {  subset =c(subset, (nbig*(j-1)) + (1:n) ) }

y1 = y1F[subset]
y1bar = y1barF[subset]
y2 = y2F[subset]
y2bar = y2barF[subset]
xm = xmF[subset]
Y = cbind(y1,y2)
Y = rbind(Y,c(NA,NA))
p.list <- list(a=2,Binv=diag(2),c=2,Dinv=diag(2))
p = pan(Y, subj = xm, pred = matrix(1,nrow=n*m,ncol=1),zcol=1,xcol=1, prior = p.list, seed=runif(1)*90, iter=1500)

# derive conditional parameters from the joint samples
P = p$psi
E = p$sigma
B = p$beta

sig1.2 = E[1,1,]-(E[1,2,]^2)/E[2,2,]
psi1.2 = P[1,1,] - ( ( 2*E[1,2,]*E[2,2,]*P[1,2,] - E[1,2,]^2*P[2,2,] + n*E[2,2,]*P[1,2,]^2 )/ ( E[2,2,]*(E[2,2,]+n*P[2,2,]) ) )
beta1.2 = P[1,2,]/E[2,2,] - ( (E[1,2,]*P[2,2,] + P[1,2,]*P[2,2,]*n)/ (E[2,2,]*(E[2,2,]+P[2,2,]*n)))
beta2.2 = E[1,2,]/E[2,2,]
beta2.1 = E[1,2,]/E[1,1,]
beta1.1 = P[1,2,]/E[1,1,] - ( (E[1,2,]*P[1,1,] + P[1,2,]*P[1,1,]*n)/ (E[1,1,]*(E[1,1,]+P[1,1,]*n)))
beta0.2 = B[1,1,] - (beta2.2 + beta1.2*n ) * B[1,2,]

Y1.pred = matrix(NA,nrow=1500,ncol=n*m)
mu_y1 = matrix(NA,nrow=1500, ncol=n*m) 
for(j in 1:1500)
  {
  mu_y1[j,] = beta0.2[j] + beta1.2[j]*(y2bar) + beta2.2[j]*y2
  b = rnorm(m,0,sqrt(psi1.2[j]))
  for( i in 1:(n*m))
    { Y1.pred[j,i] = rnorm(1,mu_y1[j,i],sqrt(sig1.2[j]))+b[x[i]] }   # Sample  from predictive dist. of y1
  }

# MICE
y1_s = as.matrix(c(y1,NA))
p2.list <- list(a=1,Binv=diag(1),c=1,Dinv=diag(1))
p2 = pan(y1_s, subj = as.factor(as.numeric(xm)), pred = cbind(matrix(1,nrow=n*m,ncol=1), y2,y2bar),zcol=1,xcol=c(1,2,3), prior = p2.list, seed=runif(1)*90, iter=1500)

y1_pred2 =matrix(NA, ncol = n*m, nrow = nrow(Y1.pred))
for( j in 1:nrow(Y1.pred))
  {
  mu.vec = p2$beta[1,1,j]+p2$beta[2,1,j]*y2 + p2$beta[3,1,j]*y2bar
  b = rnorm(m,0,sqrt(p2$psi[1,1,j]))
  y1_pred2[j,] = rnorm(n*m, mu.vec, sqrt(p2$sigma[1,1,j]))+ X[subset,1:m]%*%b  # Generate from predictive dist. of Y1
  }

# row 3 is m30n10, row 1 is m5n10 
# row 4: m30, n30, row 2: m5, n30
s1[row,,]= y1_pred2[,(1:4*n)]
s2[row,,] = Y1.pred[,1:4*n]
}

# Create QQplots 
par(mfrow=c(4,4), cex=0.75, mar=c(3.1,3.1,1,0.5), mgp=c(1.8,0.5,0), bty="L")

for( k in 1:4){
for( j in 1:4){

 r = range(s1[k,,j],s2[k,,j] )
 plot(s2[k,,j][order(s2[k,,j])], s1[k,,j][order(s1[k,,j])],
 ylab="FCS I-W prior", xlab="Joint prior",xlim = r*1.04, ylim=r*1.04, pch=18,cex.lab=1.3,cex.axis=1.2)
 abline(a=0,b=1,lty=2)
}
}

# ==========================================================
# Plot of priors for simulation 5
# ==========================================================
library("ggplot2")
Lambda1 = as.matrix(diag(c(1,1)))

# samples from IW_1 priors used in MICE
prior1 = 1/rWishart(10000,1,as.matrix(1))[1,1,]
prior2 = 1/rWishart(10000,1.6,as.matrix(1))[1,1,]
prior3 = 1/rWishart(10000,5,as.matrix(1))[1,1,]

dens.fact =factor(c(rep(1,10000),rep(2,10000), rep(3,10000)), labels= c("IW(1,1)", "IW(1.6,1)", "IW(5,1)"))
psi.samples = as.data.frame(cbind( c(prior1,prior2,prior3), dens.fact ))
dens.fact =factor(c(rep("IW(1,1)",10000),rep("IW(1,1)",10000), rep("IW(1,1)",10000)))

my.labs = list("IW(1,1)", "IW(1.6,1)", "IW(5,1)")

m1 <- ggplot(psi.samples, aes(x = V1))+ scale_color_grey() + geom_density(aes(linetype=factor(c(rep("IW(1,1)",10000),rep("IW(1.6,1)",10000), rep("IW(5,1)",10000)))
), alpha=.6) + scale_x_continuous(limits = c(0, 6))  + 
  theme_bw() +
  theme(legend.text = element_text( size = 14), legend.title = element_text(size = 14),
        axis.text = element_text(size=16),axis.title = element_text(size=16))+ xlab(expression( psi)) +
  guides(linetype = guide_legend(title = "Prior", labels=c(my.labs), size=16)) 

m1

