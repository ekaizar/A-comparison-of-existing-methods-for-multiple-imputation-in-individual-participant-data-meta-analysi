# =========================================
# TBI data analysis
# Example 1: impute t-internalizing and -externalizing scores
# response variable is BSIg
# =========================================

# Revised March 2017
library("mice")
library("lme4")
library("MASS")
library("pan")
library(abind)
library("xtable")

setwd("U:\\")
load("TBI_2016-08.Rdata")
setwd("~/2016-10 MICE paper")
source('TBI_example_functions.R')
factor=as.factor(tbi[,3]*tbi[,11]) # indicator of psuedostudy

#########################
# pseudo study key:
# factor 1 : study1, site1
# factor 2 : study1, site 2
# factor 3 : study1, site 3
# facotr 4 : study2, site 2
# factor 6 : study2, site 3


basecol=c(4,12,14,16,17)  # group, sex, ageatinjury, age, race, maternal ed
tbi$group[which(tbi$group==3 | tbi$group ==4 )] = 2   # combine mild, moderate, and mild complicated groups 
t2 = dirty.data(tbi,c(basecol,178,179,60),visitn=3, groups = 1:4)   # keep sporadic missingness. only include groups 1:4

X_group = model.matrix( ~0 + as.factor(t2$tbi[,1]))[,-1]
#subset the data
y.tot2 = cbind(X_group,t2$tbi[,c(2:5,8,6:7)],as.numeric(t2$factor),rep(1,length(t2$factor)))
fact.col=dim(y.tot2)[2]-1 # where the factor falls in the dataframe

y.nomiss = y.tot2
fact.nomiss = t2$factor
ps1=which(y.tot2[,fact.col]==1)    # indices of each pseudo-study
ps2=which(y.tot2[,fact.col]==2)
ps3=which(y.tot2[,fact.col]==3)
ps4=which(y.tot2[,fact.col]==4)
ps5=which(y.tot2[,fact.col]==5)

# ================================
#  summaries of data
# ================================

NArows = apply(y.tot2,1,nacol)
c_case = which(NArows == 0)

summary.table = matrix(NA, nrow = ncol(y.tot2[,1:8]), ncol=5)

for ( j in 1:ncol(y.tot2[,1:8]))
{
 Q= paste(formatC(tapply(y.tot2[c_case,j],t2$factor[c_case],mean),digits=3,format="f"), " (",formatC (tapply(y.tot2[c_case,j],t2$factor[c_case],sd),digits=2,format="f"), ")", sep="")
 summary.table[j,] = Q
}

summary.table = as.data.frame(summary.table)
rownames(summary.table) = names(t2$tbi)
colnames(summary.table) = c("pTBI- Site 1", "pTBI - Site 2", "pTBI - Site 3",
	 "TBI - Site 2", "TBI - Site 3")
xtable(summary.table)


nimp=45; nit = 200



# ==========================================
# Impute only sporadic missingness on full data.
# Column 5: maternal Ed 3 missing
# Columns 6,7: CBC int and ext : 3 missing
# Column 8 : BSI 8 missing
# ==========================================

init_f = mice(y.tot2, nit=0)
pred_f = init_f$pred

pred_f[5,] = c( rep(1,4),0,1,1,1,-2,1)   # mat ed
pred_f[6,] = c( rep(1,5),0,1,1,-2,1)     # BSI
pred_f[7,] = c( rep(1,6),0,1,-2,1)       # CBC int
pred_f[8,] = c( rep(1,7),0,-2,1)         # CBC ext

impm_f =mice(y.tot2,predictorMatrix=pred_f,m=nimp,method=c("","","","","2l.pan","2l.pan","2l.pan","2l.pan","",""),maxit=55)

#par(ask=T)
#plot(impm_f)
m5 = which(is.na(y.tot2[,5])) 
m6 = which(is.na(y.tot2[,6])) 
m7 = which(is.na(y.tot2[,7])) 
m8 = which(is.na(y.tot2[,8])) 

f_completed_data = NULL
for( q in 1:nimp)
{

	f_completed_data = abind( f_completed_data, y.tot2, along=3)
	f_completed_data[m5,5,q] =  impm_f$imp[[5]][,q]
	f_completed_data[m6,6,q] =   impm_f$imp[[6]][,q]
	f_completed_data[m7,7,q] =   impm_f$imp[[7]][,q]
	f_completed_data[m8,8,q] =   impm_f$imp[[8]][,q]
}


fulldata.est_covariates = analyze_TBI_imp(f_completed_data, 6,x_fact = fact.nomiss, x_cols = c(1:5,7:8))  

############################################
# Part 2: generate systematic missingness
# "ytot2" is no longer full data.

y.tot2[ps2,7] = NA
y.tot2[ps5,8] = NA

m5 = which(is.na(y.tot2[,5])) 
m6 = which(is.na(y.tot2[,6])) 
m7 = which(is.na(y.tot2[,7])) 
m8 = which(is.na(y.tot2[,8]))  

# ================================
# initialize for mice using pan
# case 1: ybar omitted
# ================================

init=mice(y.tot2,nit=0)
pred1=init$pred

pred1[5,] = c( rep(1,4),0,1,1,1,-2,1)   # mat ed
pred1[6,] = c( rep(1,5),0,1,1,-2,1)     # BSI
pred1[7,] = c( rep(1,6),0,1,-2,1)       # CBC int
pred1[8,] = c( rep(1,7),0,-2,1)         # CBC ext

impm2=mice(y.tot2,predictorMatrix=pred1,m=nimp,method=c("","","","","2l.pan","2l.pan","2l.pan","2l.pan","",""),maxit=55)


miceiw_completed_data = NULL
for( q in 1:nimp)
{

	miceiw_completed_data = abind( miceiw_completed_data, y.tot2, along=3)
	miceiw_completed_data[m5,5,q] =  impm2$imp[[5]][,q]
	miceiw_completed_data[m6,6,q] =   impm2$imp[[6]][,q]
	miceiw_completed_data[m7,7,q] =   impm2$imp[[7]][,q]
	miceiw_completed_data[m8,8,q] =   impm2$imp[[8]][,q]
}

mice.iwR = analyze_TBI_imp(miceiw_completed_data, 6,x_fact = fact.nomiss, x_cols = c(1:5,7:8))

# ================================
# initialize for mice using pan
# case 2: compatible mice
# ================================

init=mice(y.tot2,nit=0)
pred1=init$pred

pred1[5,] = c( rep(1,4),0,1,3,3,-2,1)   # mat ed
pred1[6,] = c( rep(1,4),1,0,3,3,-2,1)     # BSI
pred1[7,] = c( rep(1,4),1,1,0,3,-2,1)       # CBC int
pred1[8,] = c( rep(1,4),1,1,3,0,-2,1)         # CBC ext


impm_compat =mice((y.tot2),predictorMatrix=pred1,m=nimp,method=c("","","","","2l.pan","2l.pan","2l.pan","2l.pan","",""),maxit=100)
#par(ask=T)
#plot(impm_compat)

micecompat_completed_data = NULL
for( q in 1:nimp)
{

	micecompat_completed_data = abind( micecompat_completed_data, y.tot2, along=3)
	micecompat_completed_data[m5,5,q] =  impm_compat$imp[[5]][,q]
	micecompat_completed_data[m6,6,q] =   impm_compat$imp[[6]][,q]
	micecompat_completed_data[m7,7,q] =   impm_compat$imp[[7]][,q]
	micecompat_completed_data[m8,8,q] =   impm_compat$imp[[8]][,q]
}



mice.iw.compat = analyze_TBI_imp(micecompat_completed_data, 6,x_fact = fact.nomiss, x_cols = c(1:5,7:8))


# ================================
# MICE-ML
# ================================
miceML_imps = MICE_ML2_tbi1( fact.nomiss, y.tot2[,5:8], X.dat = y.tot2[,1:4],  nimp = nimp, n.it = 50)


miceML_completed_data = NULL
for( q in 1:nimp)
{
	miceML_completed_data = abind( miceML_completed_data, y.tot2, along=3)
	miceML_completed_data[,5,q] =  miceML_imps[q,,1]
	miceML_completed_data[,6,q] =   miceML_imps[q,,2]
	miceML_completed_data[,7,q] =    miceML_imps[q,,3]
	miceML_completed_data[,8,q] =    miceML_imps[q,,4]

}

miceRR = analyze_TBI_imp(miceML_completed_data, 6,x_fact = fact.nomiss, x_cols = c(1:5,7:8))

# ================================
# joint imputation using pan
# ================================
library("pan")
pan.comp3X = array( NA, dim=c(nimp,dim(y.tot2[,5:8])))
pri=list(a=4,Binv=diag(rep(1,4)),c=4,Dinv=diag(rep(1,4)))

for( j in 1:nimp)
{
  imp3X=pan(as.matrix(y.tot2[,c(5,6,7,8)]),as.factor(as.numeric(fact.nomiss)),pred=as.matrix(y.tot2[,c(1:4,10)]),xcol=c(1:5),zcol=5,prior=pri,seed=round(runif(1, 1, 10^7)),iter=20000)      # y.tot cols+1 is intercept
  pan.comp3X[j,1:184,1:4]=imp3X$y[1:184,1:4] 
}


joint_completed_data = NULL
for( q in 1:nimp)
{

	joint_completed_data = abind( joint_completed_data, y.tot2, along=3)
	joint_completed_data[m5,5,q] =  pan.comp3X[q, m5,5-4]
	joint_completed_data[m6,6,q] =   pan.comp3X[q, m6,6-4]
	joint_completed_data[m7,7,q] =   pan.comp3X[q, m7,7-4]
	joint_completed_data[m8,8,q] =   pan.comp3X[q,m8 ,8-4]
}


joint = analyze_TBI_imp(joint_completed_data, 6,x_fact = fact.nomiss, x_cols = c(1:5,7:8))

# ================================
#  Make table summarizing results
# ================================

library("xtable")

fulldata = matrix(NA,nrow=nrow(fulldata.est_covariates),ncol=5)
fulldata[,1] =as.matrix( paste(formatC(fulldata.est_covariates[,1],digits=3,format="f"),
	 " (",formatC(fulldata.est_covariates[,2],digits=2,format="f"), ")", sep="" ) )
fulldata[,2] = as.matrix( paste(formatC(mice.iwR[,1],digits=3,format="f"),
	 " (",formatC(mice.iwR[,4],digits=2,format="f"), ")", sep="" ) )
fulldata[,3] = as.matrix( paste(formatC(mice.iw.compat[,1],digits=3,format="f"),
	 " (",formatC(mice.iw.compat[,4],digits=2,format="f"), ")", sep="" ) )

fulldata[,4] =as.matrix( paste(formatC(miceML[,1],digits=3,format="f"),
	 " (",formatC(miceML[,4],digits=2,format="f"), ")", sep="" ) )
fulldata[,5] =as.matrix( paste(formatC(joint[,1],digits=3,format="f"),
	 " (",formatC(joint[,4],digits=2,format="f"), ")", sep="" ) )

fulldata = fulldata[,c(1,5,2:4)]
rownames(fulldata) = c("Intercept",names(y.nomiss)[7:8],c("Group Mild/Mod"),names(y.nomiss[,2:5]),"Error variance",
"Random effect variance")
colnames(fulldata) = c("Full data", "MICE-IW", "MICE-IW (c) ", "MICE-ML", "Joint")[c(1,5,2:4)]
xtable(fulldata)


